package com.delhibus.app

import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

class MainActivity : ComponentActivity() {

    override fun attachBaseContext(newBase: Context) {
        val lang = Prefs.str(newBase, "lang", "")
        if (lang.isEmpty()) {
            super.attachBaseContext(newBase)
            return
        }
        val locale = Locale(lang)
        Locale.setDefault(locale)
        val cfg = Configuration(newBase.resources.configuration)
        cfg.setLocale(locale)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DelhiBusApp(onLang = { l ->
                Prefs.setStr(this, "lang", l)
                recreate()
            })
        }
    }
}

enum class Screen { LANG, DEMO, PERMS, MAP, SETTINGS, PERMCHECK }

private val lightScheme = lightColorScheme(
    primary = Color(0xFF0B6B3A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFB7F0CC),
    onPrimaryContainer = Color(0xFF00210F)
)

private val darkScheme = darkColorScheme(
    primary = Color(0xFF7CD9A0),
    onPrimary = Color(0xFF00391B),
    primaryContainer = Color(0xFF00522B),
    onPrimaryContainer = Color(0xFFB7F0CC)
)

private fun startScreen(c: Context): Screen = when {
    Prefs.str(c, "lang", "").isEmpty() -> Screen.LANG
    !Prefs.bool(c, "demo_seen", false) -> Screen.DEMO
    !Prefs.bool(c, "onboarded", false) -> Screen.PERMS
    else -> Screen.MAP
}

@Composable
fun DelhiBusApp(onLang: (String) -> Unit) {
    val ctx = LocalContext.current
    var theme by remember { mutableStateOf(Prefs.str(ctx, "theme", "system")) }
    val dark = when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    MaterialTheme(colorScheme = if (dark) darkScheme else lightScheme) {
        Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
            var screen by remember { mutableStateOf(startScreen(ctx)) }
            val update = remember { UpdateState(ctx.applicationContext) }
            val data by produceState<TransitData?>(null) {
                value = withContext(Dispatchers.IO) {
                    try {
                        TransitData.load(ctx)
                    } catch (e: Exception) {
                        null
                    }
                }
            }

            BackHandler(enabled = screen == Screen.SETTINGS || screen == Screen.PERMCHECK) {
                screen = if (screen == Screen.PERMCHECK) Screen.SETTINGS else Screen.MAP
            }

            when (screen) {
                Screen.LANG -> LanguageScreen(onPick = onLang)
                Screen.DEMO -> DemoScreen(onNext = {
                    Prefs.setBool(ctx, "demo_seen", true)
                    screen = if (Prefs.bool(ctx, "onboarded", false)) Screen.MAP else Screen.PERMS
                })
                Screen.PERMS -> OnboardingScreen(onFinish = {
                    Prefs.setBool(ctx, "onboarded", true)
                    screen = Screen.MAP
                })
                Screen.MAP -> MapScreen(data = data, update = update, onSettings = { screen = Screen.SETTINGS })
                Screen.SETTINGS -> SettingsScreen(
                    update = update,
                    theme = theme,
                    onTheme = { t ->
                        Prefs.setStr(ctx, "theme", t)
                        theme = t
                    },
                    onLang = onLang,
                    onPermCheck = { screen = Screen.PERMCHECK },
                    onBack = { screen = Screen.MAP }
                )
                Screen.PERMCHECK -> PermCheckScreen(onBack = { screen = Screen.SETTINGS })
            }
        }
    }
}
