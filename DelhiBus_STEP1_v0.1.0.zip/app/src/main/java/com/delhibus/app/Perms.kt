package com.delhibus.app

import android.Manifest
import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver

enum class Perm(val title: Int, val why: Int, val denied: Int) {
    LOCATION(R.string.p1_title, R.string.p1_why, R.string.p1_denied),
    BG_LOCATION(R.string.p2_title, R.string.p2_why, R.string.p2_denied),
    NOTIF(R.string.p3_title, R.string.p3_why, R.string.p3_denied),
    BATTERY(R.string.p4_title, R.string.p4_why, R.string.p4_denied),
    ALARM(R.string.p5_title, R.string.p5_why, R.string.p5_denied),
    INSTALL(R.string.p6_title, R.string.p6_why, R.string.p6_denied)
}

object Perms {
    private fun has(c: Context, p: String) =
        ContextCompat.checkSelfPermission(c, p) == PackageManager.PERMISSION_GRANTED

    fun isGranted(c: Context, p: Perm): Boolean = when (p) {
        Perm.LOCATION -> has(c, Manifest.permission.ACCESS_FINE_LOCATION)
        Perm.BG_LOCATION ->
            if (Build.VERSION.SDK_INT >= 29) has(c, Manifest.permission.ACCESS_BACKGROUND_LOCATION)
            else has(c, Manifest.permission.ACCESS_FINE_LOCATION)
        Perm.NOTIF ->
            if (Build.VERSION.SDK_INT >= 33) has(c, Manifest.permission.POST_NOTIFICATIONS) else true
        Perm.BATTERY -> {
            val pm = c.getSystemService(Context.POWER_SERVICE) as PowerManager
            pm.isIgnoringBatteryOptimizations(c.packageName)
        }
        Perm.ALARM ->
            if (Build.VERSION.SDK_INT >= 31) {
                val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                am.canScheduleExactAlarms()
            } else true
        Perm.INSTALL -> c.packageManager.canRequestPackageInstalls()
    }

    fun appDetails(c: Context): Intent =
        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.packageName))

    fun settingsIntent(c: Context, p: Perm): Intent {
        val u = Uri.parse("package:" + c.packageName)
        return when (p) {
            Perm.BATTERY -> Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, u)
            Perm.ALARM ->
                if (Build.VERSION.SDK_INT >= 31) Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, u)
                else appDetails(c)
            Perm.INSTALL -> Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, u)
            else -> appDetails(c)
        }
    }
}

/** Counter that goes up every time the screen comes back to the front. */
@Composable
fun rememberResumeTick(): State<Int> {
    val tick = remember { mutableStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) tick.value = tick.value + 1
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return tick
}

/** Returns a function that asks for a permission (system dialog or system settings page). */
@Composable
fun rememberPermRequester(onResult: () -> Unit): (Perm) -> Unit {
    val ctx = LocalContext.current
    val multi = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { onResult() }
    val single = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { onResult() }
    return { p ->
        try {
            when (p) {
                Perm.LOCATION -> multi.launch(
                    arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
                )
                Perm.BG_LOCATION -> {
                    if (Build.VERSION.SDK_INT >= 29 && Perms.isGranted(ctx, Perm.LOCATION)) {
                        single.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                    } else {
                        ctx.startActivity(Perms.appDetails(ctx))
                    }
                }
                Perm.NOTIF -> {
                    if (Build.VERSION.SDK_INT >= 33) single.launch(Manifest.permission.POST_NOTIFICATIONS)
                    else onResult()
                }
                else -> ctx.startActivity(Perms.settingsIntent(ctx, p))
            }
        } catch (e: Exception) {
            try {
                ctx.startActivity(Perms.appDetails(ctx))
            } catch (e2: Exception) {
                // nothing more we can do
            }
        }
    }
}
