package com.delhibus.app

import android.content.Context

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("delhibus", Context.MODE_PRIVATE)

    fun str(c: Context, k: String, d: String): String = sp(c).getString(k, d) ?: d
    fun bool(c: Context, k: String, d: Boolean): Boolean = sp(c).getBoolean(k, d)
    fun int(c: Context, k: String, d: Int): Int = sp(c).getInt(k, d)

    fun setStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun setBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
    fun setInt(c: Context, k: String, v: Int) { sp(c).edit().putInt(k, v).apply() }
}
