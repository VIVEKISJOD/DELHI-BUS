package com.delhibus.app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

@Composable
fun Gap(h: Int = 12) {
    Spacer(Modifier.height(h.dp))
}

// ---------------------------------------------------------------- first screens

@Composable
fun LanguageScreen(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Delhi Bus  |  दिल्ली बस", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Gap(24)
        Text(stringResource(R.string.lang_title), style = MaterialTheme.typography.titleMedium)
        Gap(16)
        Button(onClick = { onPick("en") }, modifier = Modifier.fillMaxWidth()) { Text("English") }
        Gap(12)
        Button(onClick = { onPick("hi") }, modifier = Modifier.fillMaxWidth()) { Text("हिन्दी") }
        Gap(16)
        Text(stringResource(R.string.lang_note), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun DemoScreen(onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Gap(24)
        Text(stringResource(R.string.demo_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Gap(20)
        Text(stringResource(R.string.demo_1), style = MaterialTheme.typography.bodyLarge)
        Gap()
        Text(stringResource(R.string.demo_2), style = MaterialTheme.typography.bodyLarge)
        Gap()
        Text(stringResource(R.string.demo_3), style = MaterialTheme.typography.bodyLarge)
        Gap()
        Text(stringResource(R.string.demo_4), style = MaterialTheme.typography.bodyLarge)
        Gap(16)
        Text(stringResource(R.string.demo_note), style = MaterialTheme.typography.bodySmall)
        Gap(24)
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.continue_btn)) }
    }
}

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val perms = Perm.values()
    var idx by remember { mutableStateOf(0) }
    var local by remember { mutableStateOf(0) }
    val tick = rememberResumeTick()
    val request = rememberPermRequester { local = local + 1 }
    val p = perms[idx]
    val granted = remember(tick.value, local, idx) { Perms.isGranted(ctx, p) }
    val last = idx == perms.size - 1

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Gap(24)
        Text(stringResource(R.string.step_of, idx + 1, perms.size), style = MaterialTheme.typography.bodySmall)
        Gap(8)
        Text(stringResource(p.title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Gap(16)
        Text(stringResource(p.why), style = MaterialTheme.typography.bodyLarge)
        Gap(12)
        if (granted) {
            Text(stringResource(R.string.on), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        } else {
            Text(stringResource(p.denied), style = MaterialTheme.typography.bodyMedium)
        }
        Gap(24)
        Button(onClick = { request(p) }, enabled = !granted, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.allow))
        }
        Gap(8)
        OutlinedButton(
            onClick = { if (last) onFinish() else idx = idx + 1 },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                stringResource(
                    if (last) R.string.finish else if (granted) R.string.next else R.string.skip
                )
            )
        }
    }
}

@Composable
fun PermCheckScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.perm_check_title), style = MaterialTheme.typography.titleLarge)
        }
        Gap()
        for (p in Perm.values()) {
            val granted = remember(tick.value, p) { Perms.isGranted(ctx, p) }
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(
                    Modifier.padding(12.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(p.title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(if (granted) R.string.on else R.string.off),
                            color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                        if (!granted) Text(stringResource(p.denied), style = MaterialTheme.typography.bodySmall)
                    }
                    if (!granted) {
                        OutlinedButton(onClick = {
                            try {
                                ctx.startActivity(Perms.settingsIntent(ctx, p))
                            } catch (e: Exception) {
                                try {
                                    ctx.startActivity(Perms.appDetails(ctx))
                                } catch (e2: Exception) {
                                    // ignore
                                }
                            }
                        }) { Text(stringResource(R.string.open)) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- map screen

@Composable
fun OsmMap(
    user: Location?,
    nearest: Stop?,
    focus: Stop?,
    routeStops: List<Stop>,
    hindi: Boolean,
    youLabel: String,
    modifier: Modifier
) {
    val ctx = LocalContext.current
    val map = remember {
        Configuration.getInstance().userAgentValue = ctx.packageName
        Configuration.getInstance().osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
        Configuration.getInstance().osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(28.6139, 77.2090))
        }
    }
    DisposableEffect(Unit) {
        map.onResume()
        onDispose {
            map.onPause()
            map.onDetach()
        }
    }
    var centered by remember { mutableStateOf(false) }
    LaunchedEffect(user != null) {
        if (user != null && !centered) {
            centered = true
            map.controller.setZoom(16.0)
            map.controller.setCenter(GeoPoint(user.latitude, user.longitude))
        }
    }
    LaunchedEffect(focus) {
        if (focus != null) {
            map.controller.setZoom(17.0)
            map.controller.animateTo(GeoPoint(focus.lat, focus.lon))
        }
    }
    LaunchedEffect(routeStops) {
        if (routeStops.size > 1) {
            val pts = routeStops.map { GeoPoint(it.lat, it.lon) }
            map.post { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, 100) }
        }
    }
    AndroidView(
        factory = { map },
        modifier = modifier,
        update = { m ->
            m.overlays.clear()
            if (routeStops.size > 1) {
                val line = Polyline()
                line.setPoints(routeStops.map { GeoPoint(it.lat, it.lon) })
                line.outlinePaint.color = 0xFF0B6B3A.toInt()
                line.outlinePaint.strokeWidth = 10f
                m.overlays.add(line)
                for (s in routeStops) {
                    val mk = Marker(m)
                    mk.position = GeoPoint(s.lat, s.lon)
                    mk.title = s.display(hindi)
                    mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                    m.overlays.add(mk)
                }
            }
            if (nearest != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(nearest.lat, nearest.lon)
                mk.title = nearest.display(hindi)
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                m.overlays.add(mk)
            }
            if (focus != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(focus.lat, focus.lon)
                mk.title = focus.display(hindi)
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                m.overlays.add(mk)
            }
            if (user != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(user.latitude, user.longitude)
                mk.title = youLabel
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                m.overlays.add(mk)
            }
            m.invalidate()
        }
    )
}

@Composable
fun MapScreen(data: TransitData?, update: UpdateState, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val hindi = Prefs.str(ctx, "lang", "") == "hi"
    val saveMode = Prefs.bool(ctx, "gps_save", false)
    val tick = rememberResumeTick()
    val hasLoc = remember(tick.value) { Perms.isGranted(ctx, Perm.LOCATION) }
    var loc by remember { mutableStateOf<Location?>(null) }
    var query by remember { mutableStateOf("") }
    var route by remember { mutableStateOf<BusRoute?>(null) }
    var focus by remember { mutableStateOf<Stop?>(null) }
    var expanded by remember { mutableStateOf(false) }

    DisposableEffect(hasLoc, saveMode) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                loc = location
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Old Android versions still call this")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (hasLoc) {
            try {
                val providers = if (saveMode) listOf(LocationManager.NETWORK_PROVIDER)
                else listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                for (pr in providers) {
                    if (lm.isProviderEnabled(pr)) {
                        lm.requestLocationUpdates(pr, 3000L, 0f, listener, Looper.getMainLooper())
                        val known = lm.getLastKnownLocation(pr)
                        if (known != null && loc == null) loc = known
                    }
                }
            } catch (e: SecurityException) {
                // permission was taken away
            }
        }
        onDispose { lm.removeUpdates(listener) }
    }

    LaunchedEffect(Unit) {
        if (update.status == "idle") update.check()
    }
    BackHandler(route != null) { route = null }

    val nearest = remember(loc, data) {
        val l = loc
        if (l != null && data != null) data.nearest(l.latitude, l.longitude) else null
    }
    val routeStops = remember(route, data) {
        val r = route
        if (r != null && data != null) data.stopsOf(r) else emptyList()
    }

    Box(Modifier.fillMaxSize()) {
        OsmMap(
            user = loc,
            nearest = if (route == null) nearest?.first else null,
            focus = focus,
            routeStops = routeStops,
            hindi = hindi,
            youLabel = stringResource(R.string.you_are_here),
            modifier = Modifier.fillMaxSize()
        )

        Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp)) {
            Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 6.dp, shadowElevation = 6.dp) {
                Row(Modifier.padding(start = 8.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = query,
                        onValueChange = {
                            query = it
                            route = null
                        },
                        placeholder = { Text(stringResource(R.string.search_hint)) },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    TextButton(onClick = onSettings) { Text(stringResource(R.string.settings)) }
                }
            }
            if (update.status == "available") {
                Gap(6)
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.primaryContainer,
                    modifier = Modifier.fillMaxWidth().clickable { onSettings() }
                ) {
                    Text(
                        stringResource(R.string.u_banner) + ": " + (update.info?.versionName ?: ""),
                        modifier = Modifier.padding(12.dp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                }
            }
        }

        Surface(
            modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            tonalElevation = 6.dp,
            shadowElevation = 8.dp
        ) {
            Column(
                Modifier
                    .padding(16.dp)
                    .heightIn(max = if (expanded) 460.dp else 240.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "▼" else "▲") }
                val q = query.trim()
                val r = route
                if (r != null && data != null) {
                    RoutePanel(data, r, hindi) { route = null }
                } else if (q.isEmpty()) {
                    NearestCard(data, nearest, loc != null, hasLoc, hindi)
                } else if (data != null) {
                    ResultsList(
                        data, q, hindi,
                        onRoute = { route = it; focus = null },
                        onStop = { focus = it }
                    )
                }
            }
        }
    }
}

@Composable
fun NearestCard(data: TransitData?, nearest: Pair<Stop, Double>?, hasFix: Boolean, hasPerm: Boolean, hindi: Boolean) {
    Text(stringResource(R.string.nearest_stop), style = MaterialTheme.typography.labelLarge)
    Gap(4)
    if (!hasPerm) {
        Text(stringResource(R.string.no_location))
    } else if (nearest == null || !hasFix) {
        Text(stringResource(R.string.locating))
    } else {
        Text(nearest.first.display(hindi), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.away, nearest.second.toInt()))
    }
    if (data != null) {
        Gap(8)
        Text(stringResource(R.string.data_info, data.stops.size, data.routes.size), style = MaterialTheme.typography.bodySmall)
        if (data.demo) {
            Text(
                stringResource(R.string.demo_banner),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
fun ResultsList(data: TransitData, q: String, hindi: Boolean, onRoute: (BusRoute) -> Unit, onStop: (Stop) -> Unit) {
    val routes = remember(q, data) { data.searchRoutes(q) }
    val stops = remember(q, data) { data.searchStops(q) }
    if (routes.isEmpty() && stops.isEmpty()) {
        Text(stringResource(R.string.no_results))
        return
    }
    if (routes.isNotEmpty()) {
        Text(stringResource(R.string.buses), style = MaterialTheme.typography.labelLarge)
        for (r in routes) {
            Column(Modifier.fillMaxWidth().clickable { onRoute(r) }.padding(vertical = 8.dp)) {
                Text(r.number, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text(
                    data.routeTitle(r, hindi) + "  ·  " + stringResource(R.string.stops_count, r.stopIds.size),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
    if (stops.isNotEmpty()) {
        Gap(8)
        Text(stringResource(R.string.stops), style = MaterialTheme.typography.labelLarge)
        for (s in stops) {
            Text(
                s.display(hindi),
                modifier = Modifier.fillMaxWidth().clickable { onStop(s) }.padding(vertical = 8.dp)
            )
        }
    }
}

@Composable
fun RoutePanel(data: TransitData, r: BusRoute, hindi: Boolean, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(r.number, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Text(data.routeTitle(r, hindi), style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = onClose) { Text(stringResource(R.string.close)) }
    }
    Gap(8)
    val stops = data.stopsOf(r)
    for ((i, s) in stops.withIndex()) {
        Text((i + 1).toString() + ".  " + s.display(hindi), modifier = Modifier.padding(vertical = 3.dp))
    }
}

// ---------------------------------------------------------------- settings

@Composable
fun ChoiceButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

@Composable
fun SettingsScreen(
    update: UpdateState,
    theme: String,
    onTheme: (String) -> Unit,
    onLang: (String) -> Unit,
    onPermCheck: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var alarm by remember { mutableStateOf(Prefs.int(ctx, "alarm_stops", 2)) }
    var keepOn by remember { mutableStateOf(Prefs.bool(ctx, "keep_on", false)) }
    var gpsSave by remember { mutableStateOf(Prefs.bool(ctx, "gps_save", false)) }
    val lang = Prefs.str(ctx, "lang", "en")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.settings), style = MaterialTheme.typography.titleLarge)
        }
        Gap()
        Text(stringResource(R.string.s_language), fontWeight = FontWeight.Bold)
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("English", lang == "en") { if (lang != "en") onLang("en") }
            ChoiceButton("हिन्दी", lang == "hi") { if (lang != "hi") onLang("hi") }
        }
        Gap(20)
        Text(stringResource(R.string.s_theme), fontWeight = FontWeight.Bold)
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton(stringResource(R.string.theme_system), theme == "system") { onTheme("system") }
            ChoiceButton(stringResource(R.string.theme_light), theme == "light") { onTheme("light") }
            ChoiceButton(stringResource(R.string.theme_dark), theme == "dark") { onTheme("dark") }
        }
        Gap(20)
        OutlinedButton(onClick = onPermCheck, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.perm_check_title))
        }
        Gap(20)
        Text(stringResource(R.string.s_alarm, alarm), fontWeight = FontWeight.Bold)
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (alarm > 1) {
                    alarm = alarm - 1
                    Prefs.setInt(ctx, "alarm_stops", alarm)
                }
            }) { Text("−") }
            OutlinedButton(onClick = {
                if (alarm < 5) {
                    alarm = alarm + 1
                    Prefs.setInt(ctx, "alarm_stops", alarm)
                }
            }) { Text("+") }
        }
        Gap(20)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.s_keep_on), modifier = Modifier.weight(1f))
            Switch(checked = keepOn, onCheckedChange = {
                keepOn = it
                Prefs.setBool(ctx, "keep_on", it)
            })
        }
        Gap(8)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.s_gps_mode), modifier = Modifier.weight(1f))
            Switch(checked = gpsSave, onCheckedChange = {
                gpsSave = it
                Prefs.setBool(ctx, "gps_save", it)
            })
        }
        Gap(24)
        Text(stringResource(R.string.s_update), fontWeight = FontWeight.Bold)
        Gap(6)
        Text(stringResource(R.string.s_version, BuildConfig.VERSION_NAME), style = MaterialTheme.typography.bodySmall)
        Gap(8)
        UpdateSection(update) { block -> scope.launch { block() } }
        Gap(24)
        Text(stringResource(R.string.s_about), fontWeight = FontWeight.Bold)
        Gap(6)
        Text(stringResource(R.string.about_text), style = MaterialTheme.typography.bodySmall)
        Gap(24)
    }
}

@Composable
fun UpdateSection(update: UpdateState, launchIt: (suspend () -> Unit) -> Unit) {
    val ctx = LocalContext.current
    val info = update.info
    when (update.status) {
        "checking" -> Text(stringResource(R.string.u_checking))
        "none" -> Text(stringResource(R.string.u_none))
        "available" -> {
            Text(stringResource(R.string.u_available, info?.versionName ?: ""))
            Gap(8)
            Button(onClick = { launchIt { update.download() } }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.u_download))
            }
        }
        "downloading" -> {
            Text(stringResource(R.string.u_downloading, update.progress))
            Gap(8)
            LinearProgressIndicator(progress = update.progress / 100f, modifier = Modifier.fillMaxWidth())
        }
        "needperm" -> {
            Text(stringResource(R.string.u_install_perm))
            Gap(8)
            Button(onClick = { update.installNow() }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.u_install_again))
            }
        }
        "error" -> {
            Text(stringResource(R.string.u_failed), color = MaterialTheme.colorScheme.error)
            Gap(8)
            Button(onClick = { launchIt { if (update.info != null) update.download() else update.check() } }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.u_retry))
            }
        }
    }
    Gap(8)
    OutlinedButton(onClick = { launchIt { update.check() } }, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.s_update))
    }
    Gap(8)
    OutlinedButton(onClick = { Updater.openReleasePage(ctx) }, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.u_open_page))
    }
}
