package com.delhibus.app

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(
    val versionCode: Int,
    val versionName: String,
    val apkUrl: String,
    val pageUrl: String,
    val size: Long
)

object Updater {
    private const val UA = "DelhiBusApp"

    fun releasesPage(): String = "https://github.com/" + BuildConfig.GITHUB_REPO + "/releases"

    /** Blocking. Call from a background thread. Returns null when no newer version exists. */
    fun check(): UpdateInfo? {
        val url = URL("https://api.github.com/repos/" + BuildConfig.GITHUB_REPO + "/releases/latest")
        val conn = url.openConnection() as HttpURLConnection
        conn.setRequestProperty("Accept", "application/vnd.github+json")
        conn.setRequestProperty("User-Agent", UA)
        conn.connectTimeout = 15000
        conn.readTimeout = 15000
        try {
            if (conn.responseCode != 200) throw IOException("HTTP " + conn.responseCode)
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            val json = JSONObject(text)
            val tag = json.optString("tag_name", "")
            val page = json.optString("html_url", releasesPage())
            val assets = json.getJSONArray("assets")
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                val name = a.getString("name")
                val m = Regex("code(\\d+)").find(name)
                if (name.endsWith(".apk") && m != null) {
                    val code = m.groupValues[1].toInt()
                    return if (code > BuildConfig.VERSION_CODE) {
                        UpdateInfo(code, tag.removePrefix("v"), a.getString("browser_download_url"), page, a.optLong("size", -1L))
                    } else null
                }
            }
            return null
        } finally {
            conn.disconnect()
        }
    }

    /** Blocking. Downloads, checks the file, retries up to 3 times. */
    fun download(ctx: Context, info: UpdateInfo, onProgress: (Int) -> Unit): File {
        val dir = File(ctx.cacheDir, "updates")
        dir.mkdirs()
        dir.listFiles()?.forEach { it.delete() }
        val out = File(dir, "update.apk")
        var last: Exception? = null
        for (attempt in 1..3) {
            try {
                if (out.exists()) out.delete()
                val conn = URL(info.apkUrl).openConnection() as HttpURLConnection
                conn.setRequestProperty("User-Agent", UA)
                conn.connectTimeout = 20000
                conn.readTimeout = 30000
                try {
                    if (conn.responseCode != 200) throw IOException("HTTP " + conn.responseCode)
                    val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else info.size
                    var done = 0L
                    conn.inputStream.use { input ->
                        out.outputStream().use { output ->
                            val buf = ByteArray(32 * 1024)
                            while (true) {
                                val n = input.read(buf)
                                if (n < 0) break
                                output.write(buf, 0, n)
                                done += n
                                if (total > 0) onProgress(((done * 100) / total).toInt().coerceIn(0, 100))
                            }
                        }
                    }
                    if (total > 0 && done != total) throw IOException("Incomplete download")
                } finally {
                    conn.disconnect()
                }
                val pkg = ctx.packageManager.getPackageArchiveInfo(out.absolutePath, 0)
                if (pkg == null || pkg.packageName != ctx.packageName) throw IOException("Broken file")
                onProgress(100)
                return out
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: IOException("Download failed")
    }

    /** Returns false when Android still needs the "install unknown apps" permission. */
    fun install(ctx: Context, file: File): Boolean {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            val i = Intent(
                android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                Uri.parse("package:" + ctx.packageName)
            )
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return false
        }
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", file)
        val i = Intent(Intent.ACTION_VIEW)
        i.setDataAndType(uri, "application/vnd.android.package-archive")
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }

    fun openReleasePage(ctx: Context) {
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(releasesPage()))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    }
}

object Backup {
    /** Saves trips and favourites to a small file before an update (they are empty until STEP 2). */
    fun save(c: Context) {
        try {
            val sp = c.getSharedPreferences("delhibus_user", Context.MODE_PRIVATE)
            val o = JSONObject()
            o.put("favourites", sp.getString("favourites", "[]"))
            o.put("trips", sp.getString("trips", "[]"))
            File(c.filesDir, "backup.json").writeText(o.toString())
        } catch (e: Exception) {
            // backup is best effort
        }
    }
}

class UpdateState(private val ctx: Context) {
    var status by mutableStateOf("idle") // idle, checking, none, available, downloading, ready, needperm, error
    var info by mutableStateOf<UpdateInfo?>(null)
    var progress by mutableStateOf(0)
    private var file: File? = null

    suspend fun check() {
        if (status == "checking" || status == "downloading") return
        status = "checking"
        try {
            val r = withContext(Dispatchers.IO) { Updater.check() }
            info = r
            status = if (r != null) "available" else "none"
        } catch (e: Exception) {
            status = "error"
        }
    }

    suspend fun download() {
        val i = info ?: return
        status = "downloading"
        progress = 0
        try {
            val f = withContext(Dispatchers.IO) { Updater.download(ctx, i) { p -> progress = p } }
            file = f
            installNow()
        } catch (e: Exception) {
            status = "error"
        }
    }

    fun installNow() {
        val f = file ?: return
        Backup.save(ctx)
        status = try {
            if (Updater.install(ctx, f)) "ready" else "needperm"
        } catch (e: Exception) {
            "error"
        }
    }
}
