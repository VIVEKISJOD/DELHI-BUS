Optional files for the Delhi data build (read by tools/make_data.py):
  data/gtfs.zip       Delhi static GTFS zip (from otd.delhi.gov.in). If present, it is used.
  data/hi_names.tsv   Hindi stop names, one per line: English name TAB Hindi name.
If neither the GTFS_URL secret nor data/gtfs.zip exists, the app keeps the small DEMO data.
