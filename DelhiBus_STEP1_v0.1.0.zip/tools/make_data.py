#!/usr/bin/env python3
"""Builds the small Delhi data files for the app from a GTFS zip.

Source order: GTFS_URL environment variable, then data/gtfs.zip.
If there is no source or anything fails, the DEMO data already in the app is kept
(this script never breaks the build).
"""
import csv
import datetime
import io
import os
import sys
import urllib.request
import zipfile

OUT = os.path.join("app", "src", "main", "assets", "data")


def get_blob():
    url = os.environ.get("GTFS_URL", "").strip()
    if url:
        print("Downloading GTFS from GTFS_URL ...")
        req = urllib.request.Request(url, headers={"User-Agent": "DelhiBusApp"})
        with urllib.request.urlopen(req, timeout=240) as r:
            return r.read(), "GTFS_URL"
    if os.path.exists(os.path.join("data", "gtfs.zip")):
        print("Using data/gtfs.zip")
        with open(os.path.join("data", "gtfs.zip"), "rb") as f:
            return f.read(), "data/gtfs.zip"
    return None, ""


def rows(z, member):
    with z.open(member) as f:
        for r in csv.DictReader(io.TextIOWrapper(f, encoding="utf-8-sig", newline="")):
            yield r


def clean(s):
    return (s or "").replace("\t", " ").replace("\n", " ").replace("\r", " ").strip()


def load_hindi():
    names = {}
    p = os.path.join("data", "hi_names.tsv")
    if os.path.exists(p):
        with open(p, encoding="utf-8") as f:
            for line in f:
                parts = line.rstrip("\n").split("\t")
                if len(parts) >= 2 and parts[0].strip():
                    names[parts[0].strip().lower()] = parts[1].strip()
    return names


def build(blob, source):
    z = zipfile.ZipFile(io.BytesIO(blob))
    files = {os.path.basename(n): n for n in z.namelist()}
    for need in ("stops.txt", "routes.txt", "trips.txt", "stop_times.txt"):
        if need not in files:
            raise RuntimeError("missing " + need + " in GTFS zip")

    routes = {}
    for r in rows(z, files["routes.txt"]):
        rid = r["route_id"]
        routes[rid] = (clean(r.get("route_short_name")) or rid, clean(r.get("route_long_name")))

    trip_route = {}
    for t in rows(z, files["trips.txt"]):
        trip_route[t["trip_id"]] = t["route_id"]

    count = {}
    for st in rows(z, files["stop_times.txt"]):
        tid = st["trip_id"]
        count[tid] = count.get(tid, 0) + 1

    best = {}
    for tid, c in count.items():
        rid = trip_route.get(tid)
        if rid is None or rid not in routes:
            continue
        if rid not in best or c > best[rid][0]:
            best[rid] = (c, tid)
    chosen = {v[1]: k for k, v in best.items()}

    seqs = {}
    for st in rows(z, files["stop_times.txt"]):
        tid = st["trip_id"]
        if tid in chosen:
            seqs.setdefault(tid, []).append((int(float(st["stop_sequence"])), st["stop_id"]))

    all_stops = {}
    for s in rows(z, files["stops.txt"]):
        try:
            all_stops[s["stop_id"]] = (clean(s["stop_name"]), float(s["stop_lat"]), float(s["stop_lon"]))
        except (KeyError, ValueError):
            continue

    hindi = load_hindi()
    route_lines = []
    used = set()
    for tid, rid in sorted(chosen.items(), key=lambda kv: routes[kv[1]][0]):
        ids = [sid for _, sid in sorted(seqs.get(tid, []))]
        ids = [i for i in ids if i in all_stops]
        if len(ids) < 2:
            continue
        used.update(ids)
        short, long_ = routes[rid]
        route_lines.append("\t".join([rid, short, long_ or short, ",".join(ids)]))

    stop_lines = []
    for sid in sorted(used):
        name, lat, lon = all_stops[sid]
        stop_lines.append("\t".join([sid, name, hindi.get(name.lower(), ""), "%.6f" % lat, "%.6f" % lon]))

    if len(route_lines) < 5 or len(stop_lines) < 5:
        raise RuntimeError("too little data after processing")

    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "stops.tsv"), "w", encoding="utf-8") as f:
        f.write("# id\tname\tname_hi\tlat\tlon\n" + "\n".join(stop_lines) + "\n")
    with open(os.path.join(OUT, "routes.tsv"), "w", encoding="utf-8") as f:
        f.write("# id\tnumber\ttitle\tstop ids\n" + "\n".join(route_lines) + "\n")
    with open(os.path.join(OUT, "meta.txt"), "w", encoding="utf-8") as f:
        f.write("demo=0\nsource=%s\nbuilt=%s\n" % (source, datetime.date.today().isoformat()))
    print("Wrote %d stops and %d routes" % (len(stop_lines), len(route_lines)))


def main():
    try:
        blob, source = get_blob()
        if blob is None:
            print("No GTFS source found. Keeping DEMO data.")
            return 0
        build(blob, source)
    except Exception as e:  # never break the build because of data
        print("WARNING: data build failed (" + str(e) + "). Keeping DEMO data.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
