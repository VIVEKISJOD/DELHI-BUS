package com.delhibus.app

import android.content.Context
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

data class Stop(val id: String, val name: String, val nameHi: String, val lat: Double, val lon: Double) {
    fun display(hindi: Boolean): String = if (hindi && nameHi.isNotBlank()) nameHi else name
}

data class BusRoute(val id: String, val number: String, val title: String, val stopIds: List<String>)

fun distanceM(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val r = 6371000.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2).pow(2) + cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2).pow(2)
    return 2 * r * asin(min(1.0, sqrt(a)))
}

class TransitData(
    val stops: Map<String, Stop>,
    val routes: List<BusRoute>,
    val demo: Boolean
) {
    fun nearest(lat: Double, lon: Double): Pair<Stop, Double>? {
        var best: Stop? = null
        var bestD = Double.MAX_VALUE
        for (s in stops.values) {
            val d = distanceM(lat, lon, s.lat, s.lon)
            if (d < bestD) {
                bestD = d
                best = s
            }
        }
        val b = best ?: return null
        return Pair(b, bestD)
    }

    fun searchRoutes(q: String): List<BusRoute> {
        val t = q.trim().lowercase()
        if (t.isEmpty()) return emptyList()
        return routes.filter { it.number.lowercase().startsWith(t) || it.title.lowercase().contains(t) }.take(30)
    }

    fun searchStops(q: String): List<Stop> {
        val t = q.trim().lowercase()
        if (t.isEmpty()) return emptyList()
        return stops.values.filter { it.name.lowercase().contains(t) || it.nameHi.contains(t) }
            .sortedWith(compareBy({ !it.name.lowercase().startsWith(t) }, { it.name }))
            .distinctBy { it.name.lowercase() }
            .take(30)
    }

    fun stopsOf(r: BusRoute): List<Stop> = r.stopIds.mapNotNull { stops[it] }

    fun routeTitle(r: BusRoute, hindi: Boolean): String {
        val s = stopsOf(r)
        if (s.size < 2) return r.title
        return s.first().display(hindi) + " → " + s.last().display(hindi)
    }

    companion object {
        fun load(ctx: Context): TransitData {
            fun lines(name: String): List<String> =
                ctx.assets.open("data/$name").bufferedReader(Charsets.UTF_8).use { it.readLines() }

            val stops = HashMap<String, Stop>()
            for (l in lines("stops.tsv")) {
                if (l.isBlank() || l.startsWith("#")) continue
                val p = l.split("\t")
                if (p.size < 5) continue
                val lat = p[3].toDoubleOrNull() ?: continue
                val lon = p[4].toDoubleOrNull() ?: continue
                stops[p[0]] = Stop(p[0], p[1], p[2], lat, lon)
            }
            val routes = ArrayList<BusRoute>()
            for (l in lines("routes.tsv")) {
                if (l.isBlank() || l.startsWith("#")) continue
                val p = l.split("\t")
                if (p.size < 4) continue
                val ids = p[3].split(",").filter { it.isNotBlank() }
                routes.add(BusRoute(p[0], p[1], p[2], ids))
            }
            val demo = lines("meta.txt").any { it.trim() == "demo=1" }
            return TransitData(stops, routes, demo)
        }
    }
}
