package com.delhibus.app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

class MapLine(val stops: List<Stop>, val color: Int)
class Pin(val stop: Stop, val label: String)

// ---------------------------------------------------------------- map

@Composable
fun OsmMap(
    user: Location?,
    follow: Boolean,
    lines: List<MapLine>,
    pins: List<Pin>,
    fit: List<Stop>,
    focus: Stop?,
    youLabel: String,
    modifier: Modifier
) {
    val ctx = LocalContext.current
    val map = remember {
        Configuration.getInstance().userAgentValue = ctx.packageName
        Configuration.getInstance().osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
        Configuration.getInstance().osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(28.6139, 77.2090))
        }
    }
    DisposableEffect(Unit) {
        map.onResume()
        onDispose {
            map.onPause()
            map.onDetach()
        }
    }
    var centered by remember { mutableStateOf(false) }
    LaunchedEffect(user, follow) {
        if (user != null) {
            if (!centered) {
                centered = true
                map.controller.setZoom(16.0)
                map.controller.setCenter(GeoPoint(user.latitude, user.longitude))
            } else if (follow) {
                map.controller.animateTo(GeoPoint(user.latitude, user.longitude))
            }
        }
    }
    LaunchedEffect(focus) {
        if (focus != null) {
            map.controller.setZoom(17.0)
            map.controller.animateTo(GeoPoint(focus.lat, focus.lon))
        }
    }
    LaunchedEffect(fit) {
        if (fit.size > 1) {
            val pts = fit.map { GeoPoint(it.lat, it.lon) }
            map.post { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, 160) }
        } else if (fit.size == 1) {
            map.controller.setZoom(16.0)
            map.controller.animateTo(GeoPoint(fit[0].lat, fit[0].lon))
        }
    }
    AndroidView(
        factory = { map },
        modifier = modifier,
        update = { m ->
            m.overlays.clear()
            for (ln in lines) {
                if (ln.stops.size < 2) continue
                val line = Polyline()
                line.setPoints(ln.stops.map { GeoPoint(it.lat, it.lon) })
                line.outlinePaint.color = ln.color
                line.outlinePaint.strokeWidth = 12f
                m.overlays.add(line)
            }
            for (p in pins) {
                val mk = Marker(m)
                mk.position = GeoPoint(p.stop.lat, p.stop.lon)
                mk.title = p.label
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                m.overlays.add(mk)
            }
            if (focus != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(focus.lat, focus.lon)
                mk.title = focus.name
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                m.overlays.add(mk)
            }
            if (user != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(user.latitude, user.longitude)
                mk.title = youLabel
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                m.overlays.add(mk)
            }
            m.invalidate()
        }
    )
}

// ---------------------------------------------------------------- small pieces

@Composable
fun BusBadge(number: String) {
    val ctx = LocalContext.current
    val type = remember(number) { BusUi.type(ctx, number) }
    val label = BusUi.typeLabel(type)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(8.dp), color = Color(BusUi.color(number))) {
            Text(
                number,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        if (label != 0) {
            Text("  " + stringResource(label), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun TagText(text: String) {
    Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primaryContainer) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

private fun startTrip(ctx: Context, legs: List<Leg>, peak: Double): Boolean {
    if (!Perms.isGranted(ctx, Perm.LOCATION)) {
        Toast.makeText(ctx, ctx.getString(R.string.need_location), Toast.LENGTH_LONG).show()
        return false
    }
    Trip.start(legs, Prefs.int(ctx, "alarm_stops", 2), peak)
    TripService.send(ctx, TripService.ACTION_START)
    return true
}

// ---------------------------------------------------------------- main screen

@Composable
fun MapScreen(data: TransitData?, update: UpdateState, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val hindi = Prefs.str(ctx, "lang", "") == "hi"
    val saveMode = Prefs.bool(ctx, "gps_save", false)
    val tick = rememberResumeTick()
    val hasLoc = remember(tick.value) { Perms.isGranted(ctx, Perm.LOCATION) }
    var loc by remember { mutableStateOf<Location?>(null) }

    val router by produceState<Router?>(null, data) {
        value = if (data == null) null else withContext(Dispatchers.Default) {
            try {
                Router(data)
            } catch (e: Exception) {
                null
            }
        }
    }

    var fromStop by remember { mutableStateOf<Stop?>(null) }
    var fromText by remember { mutableStateOf("") }
    var toText by remember { mutableStateOf("") }
    var dest by remember { mutableStateOf<Stop?>(null) }
    var focusedField by remember { mutableStateOf(0) }
    var route by remember { mutableStateOf<BusRoute?>(null) }
    var routeAlight by remember { mutableStateOf(-1) }
    var plans by remember { mutableStateOf<List<Plan>?>(null) }
    var selected by remember { mutableStateOf(-1) }
    var searching by remember { mutableStateOf(false) }
    var focusStop by remember { mutableStateOf<Stop?>(null) }
    var pending by remember { mutableStateOf<List<Leg>?>(null) }
    val peak = remember { Router.peakFactor() }
    val sheet = remember { Animatable(0.42f) }

    DisposableEffect(hasLoc, saveMode) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                loc = location
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Old Android versions still call this")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (hasLoc) {
            try {
                val providers = if (saveMode) listOf(LocationManager.NETWORK_PROVIDER)
                else listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                for (pr in providers) {
                    if (lm.isProviderEnabled(pr)) {
                        lm.requestLocationUpdates(pr, 3000L, 0f, listener, Looper.getMainLooper())
                        val known = lm.getLastKnownLocation(pr)
                        if (known != null && loc == null) loc = known
                    }
                }
            } catch (e: SecurityException) {
                // permission was taken away
            }
        }
        onDispose { lm.removeUpdates(listener) }
    }

    LaunchedEffect(Unit) {
        if (update.status == "idle") update.check()
    }

    val tripOn = Trip.active
    val keepOn = tripOn && Prefs.bool(ctx, "keep_on", false)
    val view = LocalView.current
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    val gotFix = loc != null
    LaunchedEffect(dest, fromStop, router, gotFix) {
        plans = null
        selected = -1
        val d = dest
        val rt = router
        if (d == null || rt == null) return@LaunchedEffect
        val l = loc
        val fs = fromStop
        val sLat = fs?.lat ?: l?.latitude
        val sLon = fs?.lon ?: l?.longitude
        if (sLat == null || sLon == null) return@LaunchedEffect
        searching = true
        val res = withContext(Dispatchers.Default) {
            try {
                val fromC = rt.candidatesNear(sLat, sLon, 700.0, 8)
                val toC = rt.candidatesNear(d.lat, d.lon, 400.0, 8)
                rt.search(fromC, toC, peak)
            } catch (e: Exception) {
                emptyList<Plan>()
            }
        }
        plans = res
        searching = false
    }

    BackHandler(enabled = !tripOn && (route != null || selected >= 0 || dest != null || focusedField != 0)) {
        if (route != null) {
            route = null
            routeAlight = -1
        } else if (focusedField != 0) {
            focusedField = 0
            focusManager.clearFocus()
        } else if (selected >= 0) {
            selected = -1
        } else {
            dest = null
            toText = ""
            plans = null
        }
    }

    val nearest = remember(loc, data) {
        val l = loc
        if (l != null && data != null) data.nearest(l.latitude, l.longitude) else null
    }

    // ---- what the map shows
    val shown: Plan? = plans?.let { it.getOrNull(if (selected >= 0) selected else 0) }
    val lines = ArrayList<MapLine>()
    val pins = ArrayList<Pin>()
    var fit: List<Stop> = emptyList()
    if (tripOn) {
        lines.add(MapLine(Trip.remaining, BusUi.color(Trip.busNumber)))
        val g = Trip.getOff
        if (g != null) pins.add(Pin(g, g.display(hindi)))
    } else if (route != null && data != null) {
        val rs = data.stopsOf(route!!)
        lines.add(MapLine(rs, BusUi.color(route!!.number)))
        fit = rs
        if (rs.isNotEmpty()) pins.add(Pin(rs.first(), rs.first().display(hindi)))
        if (routeAlight in rs.indices) pins.add(Pin(rs[routeAlight], rs[routeAlight].display(hindi)))
    } else if (shown != null) {
        val all = ArrayList<Stop>()
        for (lg in shown.legs) {
            lines.add(MapLine(lg.stops, BusUi.color(lg.route.number)))
            all.addAll(lg.stops)
            pins.add(Pin(lg.stops.first(), lg.stops.first().display(hindi)))
            pins.add(Pin(lg.stops.last(), lg.stops.last().display(hindi)))
        }
        fit = all
    } else if (route == null && dest == null && nearest != null) {
        pins.add(Pin(nearest.first, nearest.first.display(hindi)))
    }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val boxH = maxHeight
        val boxPx = with(LocalDensity.current) { maxHeight.toPx() }

        OsmMap(
            user = loc,
            follow = tripOn,
            lines = lines,
            pins = pins,
            fit = fit,
            focus = if (tripOn) null else focusStop,
            youLabel = stringResource(R.string.you_are_here),
            modifier = Modifier.fillMaxSize()
        )

        if (tripOn) {
            TripCard(hindi, Modifier.align(Alignment.BottomCenter))
        } else {
            // ---- draggable bottom sheet
            Surface(
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(boxH * sheet.value),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                tonalElevation = 6.dp,
                shadowElevation = 8.dp
            ) {
                Column(Modifier.fillMaxSize()) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(32.dp)
                            .pointerInput(boxPx) {
                                detectVerticalDragGestures(
                                    onDragEnd = {
                                        scope.launch { sheet.animateTo(snapSheet(sheet.value)) }
                                    },
                                    onDragCancel = {
                                        scope.launch { sheet.animateTo(snapSheet(sheet.value)) }
                                    },
                                    onVerticalDrag = { change, dy ->
                                        change.consume()
                                        scope.launch { sheet.snapTo((sheet.value - dy / boxPx).coerceIn(0.12f, 0.72f)) }
                                    }
                                )
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            Modifier
                                .width(44.dp)
                                .height(5.dp)
                                .background(MaterialTheme.colorScheme.outline, RoundedCornerShape(3.dp))
                        )
                    }
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                    ) {
                        val rt = router
                        val r = route
                        val q = if (focusedField == 1) fromText.trim() else toText.trim()
                        if (r != null && data != null) {
                            RouteDetail(
                                data, r, hindi, routeAlight,
                                onPickStop = { i, s ->
                                    routeAlight = i
                                    focusStop = s
                                },
                                onClose = {
                                    route = null
                                    routeAlight = -1
                                },
                                onBoard = {
                                    if (rt != null && routeAlight > 0) {
                                        val l = loc
                                        val bp = if (l != null) rt.nearestPosOnRoute(r, l.latitude, l.longitude, routeAlight) else 0
                                        val b = if (bp < routeAlight) bp else 0
                                        pending = listOf(rt.makeLeg(r, b, routeAlight, 0))
                                    }
                                }
                            )
                        } else if (focusedField == 1 && data != null) {
                            Text(
                                stringResource(R.string.use_my_location),
                                style = MaterialTheme.typography.titleMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    fromStop = null
                                    fromText = ""
                                    focusedField = 0
                                    focusManager.clearFocus()
                                }.padding(vertical = 10.dp)
                            )
                            for (s in data.searchStops(q)) {
                                Text(
                                    s.display(hindi),
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        fromStop = s
                                        fromText = s.display(hindi)
                                        focusedField = 0
                                        focusManager.clearFocus()
                                    }.padding(vertical = 10.dp)
                                )
                            }
                        } else if (focusedField == 2 && q.isNotEmpty() && dest == null && data != null) {
                            val rs = remember(q, data) { data.searchRoutes(q) }
                            val ss = remember(q, data) { data.searchStops(q) }
                            if (rs.isEmpty() && ss.isEmpty()) Text(stringResource(R.string.no_results))
                            if (rs.isNotEmpty()) {
                                Text(stringResource(R.string.buses), style = MaterialTheme.typography.labelLarge)
                                for (b in rs) {
                                    Column(Modifier.fillMaxWidth().clickable {
                                        route = b
                                        routeAlight = -1
                                        focusedField = 0
                                        focusManager.clearFocus()
                                        scope.launch { sheet.animateTo(0.42f) }
                                    }.padding(vertical = 8.dp)) {
                                        BusBadge(b.number)
                                        Text(
                                            data.routeTitle(b, hindi) + "  ·  " + stringResource(R.string.stops_count, b.stopIds.size),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                }
                            }
                            if (ss.isNotEmpty()) {
                                Gap(8)
                                Text(stringResource(R.string.stops), style = MaterialTheme.typography.labelLarge)
                                for (s in ss) {
                                    Text(
                                        s.display(hindi),
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            dest = s
                                            toText = s.display(hindi)
                                            focusedField = 0
                                            focusManager.clearFocus()
                                            scope.launch { sheet.animateTo(0.42f) }
                                        }.padding(vertical = 10.dp)
                                    )
                                }
                            }
                        } else if (dest != null) {
                            val pl = plans
                            val sel = selected
                            if (searching || (pl == null && (gotFix || fromStop != null))) {
                                Text(stringResource(R.string.finding_routes))
                            } else if (pl == null) {
                                Text(stringResource(R.string.wait_fix))
                            } else if (pl.isEmpty()) {
                                Text(stringResource(R.string.no_route))
                            } else if (sel >= 0 && sel < pl.size && data != null) {
                                PlanDetail(
                                    pl[sel], dest!!, hindi, peak,
                                    onBack = { selected = -1 },
                                    onBoard = { legIndex ->
                                        pending = pl[sel].legs.drop(legIndex)
                                    }
                                )
                            } else {
                                PlanList(pl, hindi, peak) { i ->
                                    selected = i
                                    scope.launch { sheet.animateTo(0.42f) }
                                }
                            }
                        } else {
                            NearestCard(data, nearest, loc != null, hasLoc, hindi)
                        }
                    }
                }
            }

            // ---- search bar (on top of the sheet)
            Column(Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp)) {
                Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 6.dp, shadowElevation = 6.dp) {
                    Column(Modifier.padding(start = 8.dp, end = 4.dp, top = 4.dp, bottom = 4.dp)) {
                        OutlinedTextField(
                            value = fromText,
                            onValueChange = {
                                fromText = it
                                fromStop = null
                                focusedField = 1
                            },
                            placeholder = { Text(stringResource(R.string.from_hint)) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) focusedField = 1 }
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = toText,
                                onValueChange = {
                                    toText = it
                                    dest = null
                                    route = null
                                    routeAlight = -1
                                    focusedField = 2
                                },
                                placeholder = { Text(stringResource(R.string.search_hint)) },
                                singleLine = true,
                                modifier = Modifier.weight(1f).onFocusChanged { if (it.isFocused) focusedField = 2 }
                            )
                            TextButton(onClick = onSettings) { Text(stringResource(R.string.settings)) }
                        }
                    }
                }
                if (update.status == "available") {
                    Gap(6)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        modifier = Modifier.fillMaxWidth().clickable { onSettings() }
                    ) {
                        Text(
                            stringResource(R.string.u_banner) + ": " + (update.info?.versionName ?: ""),
                            modifier = Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                }
            }
        }
    }

    // ---- "Boarded" confirmation: which bus are you on?
    val pend = pending
    if (pend != null && pend.isNotEmpty()) {
        val first = pend[0]
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(stringResource(R.string.confirm_title)) },
            text = {
                Column {
                    Text(
                        first.stops.first().display(hindi) + " → " + first.stops.last().display(hindi),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (first.alts.isNotEmpty()) {
                        Gap(8)
                        for (a in first.alts) {
                            OutlinedButton(
                                onClick = {
                                    val rt = router
                                    val swapped = rt?.legWithNumber(a, first.stops.first().id, first.stops.last().id, first.walkBeforeM)
                                    if (swapped != null) {
                                        val ok = startTrip(ctx, listOf(swapped) + pend.drop(1), peak)
                                        if (ok) {
                                            pending = null
                                            selected = -1
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(stringResource(R.string.confirm_other, a)) }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val ok = startTrip(ctx, pend, peak)
                    if (ok) {
                        pending = null
                        selected = -1
                    }
                }) { Text(stringResource(R.string.confirm_yes, first.route.number)) }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

private fun snapSheet(v: Float): Float {
    val points = floatArrayOf(0.14f, 0.42f, 0.72f)
    var best = points[0]
    for (p in points) {
        if (Math.abs(p - v) < Math.abs(best - v)) best = p
    }
    return best
}

// ---------------------------------------------------------------- sheet contents

@Composable
fun NearestCard(data: TransitData?, nearest: Pair<Stop, Double>?, hasFix: Boolean, hasPerm: Boolean, hindi: Boolean) {
    Text(stringResource(R.string.nearest_stop), style = MaterialTheme.typography.labelLarge)
    Gap(4)
    if (!hasPerm) {
        Text(stringResource(R.string.no_location))
    } else if (nearest == null || !hasFix) {
        Text(stringResource(R.string.locating))
    } else {
        Text(nearest.first.display(hindi), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.away, nearest.second.toInt()))
    }
    if (data != null) {
        Gap(8)
        Text(stringResource(R.string.data_info, data.stops.size, data.routes.size), style = MaterialTheme.typography.bodySmall)
        if (data.demo) {
            Text(
                stringResource(R.string.demo_banner),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

@Composable
fun PlanList(plans: List<Plan>, hindi: Boolean, peak: Double, onPick: (Int) -> Unit) {
    for ((i, p) in plans.withIndex()) {
        Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onPick(i) }) {
            Column(Modifier.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        stringResource(R.string.plan_min, p.totalMin),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    if (p.fastest) TagText(stringResource(R.string.tag_fastest))
                    if (p.fewest) TagText(stringResource(R.string.tag_fewest))
                }
                Gap(6)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    for ((n, lg) in p.legs.withIndex()) {
                        if (n > 0) Text("  ›  ")
                        BusBadge(lg.route.number)
                    }
                }
                Gap(6)
                Text(
                    stringResource(R.string.plan_summary, p.changes, p.totalStops, p.walkStartM + p.walkEndM),
                    style = MaterialTheme.typography.bodySmall
                )
            }
        }
    }
    Gap(4)
    Text(stringResource(R.string.est_note), style = MaterialTheme.typography.bodySmall)
}

@Composable
fun PlanDetail(plan: Plan, dest: Stop, hindi: Boolean, peak: Double, onBack: () -> Unit, onBoard: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(stringResource(R.string.plan_min, plan.totalMin), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        OutlinedButton(onClick = onBack) { Text(stringResource(R.string.back_plans)) }
    }
    Gap(8)
    if (plan.walkStartM > 0 && plan.legs.isNotEmpty()) {
        Text(stringResource(R.string.walk_to, plan.walkStartM, plan.legs[0].stops.first().display(hindi)), style = MaterialTheme.typography.bodyMedium)
        Gap(8)
    }
    for ((i, lg) in plan.legs.withIndex()) {
        if (i > 0 && lg.walkBeforeM > 0) {
            Text(stringResource(R.string.walk_between, lg.walkBeforeM), style = MaterialTheme.typography.bodyMedium)
            Gap(8)
        }
        Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
            Column(Modifier.padding(12.dp)) {
                BusBadge(lg.route.number)
                Gap(6)
                Text(stringResource(R.string.board_at, lg.stops.first().display(hindi)))
                Text(stringResource(R.string.getoff_at, lg.stops.last().display(hindi)))
                Text(stringResource(R.string.leg_info, lg.stopCount, lg.rideMin(peak)), style = MaterialTheme.typography.bodySmall)
                if (lg.alts.isNotEmpty()) {
                    Text(stringResource(R.string.same_route, lg.alts.joinToString(", ")), style = MaterialTheme.typography.bodySmall)
                }
                Gap(8)
                Button(onClick = { onBoard(i) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.boarded_btn))
                }
            }
        }
    }
    if (plan.walkEndM > 0) {
        Gap(4)
        Text(stringResource(R.string.walk_end, plan.walkEndM), style = MaterialTheme.typography.bodyMedium)
    }
    Gap(8)
    Text(stringResource(R.string.est_note), style = MaterialTheme.typography.bodySmall)
}

@Composable
fun RouteDetail(
    data: TransitData,
    r: BusRoute,
    hindi: Boolean,
    alight: Int,
    onPickStop: (Int, Stop) -> Unit,
    onClose: () -> Unit,
    onBoard: () -> Unit
) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            BusBadge(r.number)
            Text(data.routeTitle(r, hindi), style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = onClose) { Text(stringResource(R.string.close)) }
    }
    Gap(8)
    val stops = data.stopsOf(r)
    if (alight in stops.indices) {
        Text(stringResource(R.string.getoff_at, stops[alight].display(hindi)), fontWeight = FontWeight.Bold)
        Gap(6)
        Button(onClick = onBoard, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.boarded_btn)) }
    } else {
        Text(stringResource(R.string.route_tap_hint), style = MaterialTheme.typography.bodyMedium)
    }
    Gap(8)
    for ((i, s) in stops.withIndex()) {
        Text(
            (i + 1).toString() + ".  " + s.display(hindi),
            fontWeight = if (i == alight) FontWeight.Bold else FontWeight.Normal,
            color = if (i == alight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.fillMaxWidth().clickable { onPickStop(i, s) }.padding(vertical = 6.dp)
        )
    }
}

// ---------------------------------------------------------------- trip card

@Composable
fun TripCard(hindi: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
        tonalElevation = 6.dp,
        shadowElevation = 8.dp
    ) {
        Column(Modifier.padding(16.dp)) {
            val off = Trip.getOff
            when (Trip.phase) {
                Phase.CHANGE -> {
                    Text(stringResource(R.string.trip_change_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Gap(4)
                    Text(
                        stringResource(R.string.trip_change_text, off?.display(hindi) ?: "", Trip.nextBus ?: ""),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Gap(10)
                    Button(onClick = { TripService.send(ctx, TripService.ACTION_NEXT) }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.trip_change_btn, Trip.nextBus ?: ""))
                    }
                }
                Phase.DONE -> {
                    Text(stringResource(R.string.trip_arrived_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Gap(4)
                    Text(stringResource(R.string.trip_arrived_text, off?.display(hindi) ?: ""), style = MaterialTheme.typography.bodyLarge)
                    Gap(10)
                    Button(onClick = { TripService.send(ctx, TripService.ACTION_STOP) }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.trip_ok))
                    }
                }
                else -> {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        BusBadge(Trip.busNumber)
                        Text(stringResource(R.string.trip_to, off?.display(hindi) ?: ""), style = MaterialTheme.typography.bodyMedium)
                    }
                    Gap(8)
                    Text(
                        stringResource(R.string.trip_next, Trip.nextStop?.display(hindi) ?: (off?.display(hindi) ?: "")),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                    Text(stringResource(R.string.trip_left, Trip.stopsLeft))
                    Text(stringResource(R.string.trip_time, Trip.minutesLeft), style = MaterialTheme.typography.bodySmall)
                    Gap(10)
                    if (Trip.ringing) {
                        Button(
                            onClick = { TripService.send(ctx, TripService.ACTION_STOP_ALARM) },
                            modifier = Modifier.fillMaxWidth()
                        ) { Text(stringResource(R.string.trip_stop_alarm)) }
                        Gap(6)
                    }
                    OutlinedButton(
                        onClick = { TripService.send(ctx, TripService.ACTION_STOP) },
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(stringResource(R.string.trip_off_btn)) }
                }
            }
        }
    }
}
