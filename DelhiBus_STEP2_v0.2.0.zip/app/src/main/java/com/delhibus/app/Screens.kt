package com.delhibus.app

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

@Composable
fun Gap(h: Int = 12) {
    Spacer(Modifier.height(h.dp))
}

// ---------------------------------------------------------------- first screens

@Composable
fun LanguageScreen(onPick: (String) -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Delhi Bus  |  दिल्ली बस", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Gap(24)
        Text(stringResource(R.string.lang_title), style = MaterialTheme.typography.titleMedium)
        Gap(16)
        Button(onClick = { onPick("en") }, modifier = Modifier.fillMaxWidth()) { Text("English") }
        Gap(12)
        Button(onClick = { onPick("hi") }, modifier = Modifier.fillMaxWidth()) { Text("हिन्दी") }
        Gap(16)
        Text(stringResource(R.string.lang_note), style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun DemoScreen(onNext: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Gap(24)
        Text(stringResource(R.string.demo_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Gap(20)
        Text(stringResource(R.string.demo_1), style = MaterialTheme.typography.bodyLarge)
        Gap()
        Text(stringResource(R.string.demo_2), style = MaterialTheme.typography.bodyLarge)
        Gap()
        Text(stringResource(R.string.demo_3), style = MaterialTheme.typography.bodyLarge)
        Gap()
        Text(stringResource(R.string.demo_4), style = MaterialTheme.typography.bodyLarge)
        Gap(16)
        Text(stringResource(R.string.demo_note), style = MaterialTheme.typography.bodySmall)
        Gap(24)
        Button(onClick = onNext, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.continue_btn)) }
    }
}

@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val ctx = LocalContext.current
    val perms = Perm.values()
    var idx by remember { mutableStateOf(0) }
    var local by remember { mutableStateOf(0) }
    val tick = rememberResumeTick()
    val request = rememberPermRequester { local = local + 1 }
    val p = perms[idx]
    val granted = remember(tick.value, local, idx) { Perms.isGranted(ctx, p) }
    val last = idx == perms.size - 1

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)) {
        Gap(24)
        Text(stringResource(R.string.step_of, idx + 1, perms.size), style = MaterialTheme.typography.bodySmall)
        Gap(8)
        Text(stringResource(p.title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Gap(16)
        Text(stringResource(p.why), style = MaterialTheme.typography.bodyLarge)
        Gap(12)
        if (granted) {
            Text(stringResource(R.string.on), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
        } else {
            Text(stringResource(p.denied), style = MaterialTheme.typography.bodyMedium)
        }
        Gap(24)
        Button(onClick = { request(p) }, enabled = !granted, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.allow))
        }
        Gap(8)
        OutlinedButton(
            onClick = { if (last) onFinish() else idx = idx + 1 },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                stringResource(
                    if (last) R.string.finish else if (granted) R.string.next else R.string.skip
                )
            )
        }
    }
}

@Composable
fun PermCheckScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val tick = rememberResumeTick()
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.perm_check_title), style = MaterialTheme.typography.titleLarge)
        }
        Gap()
        for (p in Perm.values()) {
            val granted = remember(tick.value, p) { Perms.isGranted(ctx, p) }
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                Row(
                    Modifier.padding(12.dp).fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(stringResource(p.title), fontWeight = FontWeight.Bold)
                        Text(
                            stringResource(if (granted) R.string.on else R.string.off),
                            color = if (granted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error
                        )
                        if (!granted) Text(stringResource(p.denied), style = MaterialTheme.typography.bodySmall)
                    }
                    if (!granted) {
                        OutlinedButton(onClick = {
                            try {
                                ctx.startActivity(Perms.settingsIntent(ctx, p))
                            } catch (e: Exception) {
                                try {
                                    ctx.startActivity(Perms.appDetails(ctx))
                                } catch (e2: Exception) {
                                    // ignore
                                }
                            }
                        }) { Text(stringResource(R.string.open)) }
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- settings

@Composable
fun ChoiceButton(label: String, selected: Boolean, onClick: () -> Unit) {
    if (selected) {
        Button(onClick = onClick) { Text(label) }
    } else {
        OutlinedButton(onClick = onClick) { Text(label) }
    }
}

@Composable
fun SettingsScreen(
    update: UpdateState,
    theme: String,
    onTheme: (String) -> Unit,
    onLang: (String) -> Unit,
    onPermCheck: () -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var alarm by remember { mutableStateOf(Prefs.int(ctx, "alarm_stops", 2)) }
    var keepOn by remember { mutableStateOf(Prefs.bool(ctx, "keep_on", false)) }
    var gpsSave by remember { mutableStateOf(Prefs.bool(ctx, "gps_save", false)) }
    var alarmSound by remember { mutableStateOf(Prefs.bool(ctx, "alarm_sound", true)) }
    var alarmVibrate by remember { mutableStateOf(Prefs.bool(ctx, "alarm_vibrate", true)) }
    val lang = Prefs.str(ctx, "lang", "en")

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(stringResource(R.string.back)) }
            Text(stringResource(R.string.settings), style = MaterialTheme.typography.titleLarge)
        }
        Gap()
        Text(stringResource(R.string.s_language), fontWeight = FontWeight.Bold)
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton("English", lang == "en") { if (lang != "en") onLang("en") }
            ChoiceButton("हिन्दी", lang == "hi") { if (lang != "hi") onLang("hi") }
        }
        Gap(20)
        Text(stringResource(R.string.s_theme), fontWeight = FontWeight.Bold)
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ChoiceButton(stringResource(R.string.theme_system), theme == "system") { onTheme("system") }
            ChoiceButton(stringResource(R.string.theme_light), theme == "light") { onTheme("light") }
            ChoiceButton(stringResource(R.string.theme_dark), theme == "dark") { onTheme("dark") }
        }
        Gap(20)
        OutlinedButton(onClick = onPermCheck, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.perm_check_title))
        }
        Gap(20)
        Text(stringResource(R.string.s_alarm, alarm), fontWeight = FontWeight.Bold)
        Gap(6)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                if (alarm > 1) {
                    alarm = alarm - 1
                    Prefs.setInt(ctx, "alarm_stops", alarm)
                }
            }) { Text("−") }
            OutlinedButton(onClick = {
                if (alarm < 5) {
                    alarm = alarm + 1
                    Prefs.setInt(ctx, "alarm_stops", alarm)
                }
            }) { Text("+") }
        }
        Gap(20)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.s_alarm_sound), modifier = Modifier.weight(1f))
            Switch(checked = alarmSound, onCheckedChange = {
                alarmSound = it
                Prefs.setBool(ctx, "alarm_sound", it)
            })
        }
        Gap(8)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.s_alarm_vibrate), modifier = Modifier.weight(1f))
            Switch(checked = alarmVibrate, onCheckedChange = {
                alarmVibrate = it
                Prefs.setBool(ctx, "alarm_vibrate", it)
            })
        }
        Gap(20)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.s_keep_on), modifier = Modifier.weight(1f))
            Switch(checked = keepOn, onCheckedChange = {
                keepOn = it
                Prefs.setBool(ctx, "keep_on", it)
            })
        }
        Gap(8)
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.s_gps_mode), modifier = Modifier.weight(1f))
            Switch(checked = gpsSave, onCheckedChange = {
                gpsSave = it
                Prefs.setBool(ctx, "gps_save", it)
            })
        }
        Gap(24)
        Text(stringResource(R.string.s_update), fontWeight = FontWeight.Bold)
        Gap(6)
        Text(stringResource(R.string.s_version, BuildConfig.VERSION_NAME), style = MaterialTheme.typography.bodySmall)
        Gap(8)
        UpdateSection(update) { block -> scope.launch { block() } }
        Gap(24)
        Text(stringResource(R.string.s_about), fontWeight = FontWeight.Bold)
        Gap(6)
        Text(stringResource(R.string.about_text), style = MaterialTheme.typography.bodySmall)
        Gap(24)
    }
}

@Composable
fun UpdateSection(update: UpdateState, launchIt: (suspend () -> Unit) -> Unit) {
    val ctx = LocalContext.current
    val info = update.info
    when (update.status) {
        "checking" -> Text(stringResource(R.string.u_checking))
        "none" -> Text(stringResource(R.string.u_none))
        "available" -> {
            Text(stringResource(R.string.u_available, info?.versionName ?: ""))
            Gap(8)
            Button(onClick = { launchIt { update.download() } }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.u_download))
            }
        }
        "downloading" -> {
            Text(stringResource(R.string.u_downloading, update.progress))
            Gap(8)
            LinearProgressIndicator(progress = update.progress / 100f, modifier = Modifier.fillMaxWidth())
        }
        "needperm" -> {
            Text(stringResource(R.string.u_install_perm))
            Gap(8)
            Button(onClick = { update.installNow() }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.u_install_again))
            }
        }
        "error" -> {
            Text(stringResource(R.string.u_failed), color = MaterialTheme.colorScheme.error)
            Gap(8)
            Button(onClick = { launchIt { if (update.info != null) update.download() else update.check() } }, modifier = Modifier.fillMaxWidth()) {
                Text(stringResource(R.string.u_retry))
            }
        }
    }
    Gap(8)
    OutlinedButton(onClick = { launchIt { update.check() } }, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.s_update))
    }
    Gap(8)
    OutlinedButton(onClick = { Updater.openReleasePage(ctx) }, modifier = Modifier.fillMaxWidth()) {
        Text(stringResource(R.string.u_open_page))
    }
}
