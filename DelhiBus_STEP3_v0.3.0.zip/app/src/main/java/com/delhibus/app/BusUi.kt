package com.delhibus.app

import android.content.Context

/** Colour and type of a bus. The colour is chosen from the bus number. The type comes from an optional list. */
object BusUi {
    fun color(number: String): Int {
        var h = 7
        for (c in number) h = h * 31 + c.code
        val hue = ((h and 0x7fffffff) % 360).toFloat()
        return android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.75f, 0.62f))
    }

    private var types: Map<String, String>? = null

    /** Returns AC, NONAC, EV, CLUSTER or "" when the type is not known. */
    fun type(ctx: Context, number: String): String {
        var t = types
        if (t == null) {
            val m = HashMap<String, String>()
            try {
                ctx.applicationContext.assets.open("data/bus_types.tsv").bufferedReader(Charsets.UTF_8).use { r ->
                    for (l in r.readLines()) {
                        if (l.isBlank() || l.startsWith("#")) continue
                        val p = l.split("\t")
                        if (p.size >= 2) m[p[0].trim().uppercase()] = p[1].trim().uppercase()
                    }
                }
            } catch (e: Exception) {
                // the list is optional
            }
            types = m
            t = m
        }
        return t[number.trim().uppercase()] ?: ""
    }

    fun typeLabel(type: String): Int = when (type) {
        "AC" -> R.string.bt_ac
        "NONAC" -> R.string.bt_nonac
        "EV" -> R.string.bt_ev
        "CLUSTER" -> R.string.bt_cluster
        else -> 0
    }
}
