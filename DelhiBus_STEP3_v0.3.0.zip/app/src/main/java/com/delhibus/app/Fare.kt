package com.delhibus.app

/** One fare step. toKm = -1 means "and above". */
class Slab(val fromKm: Int, val toKm: Int, val fare: Int)

/**
 * Bus fare ESTIMATE for Delhi (DTC / cluster style distance slabs).
 * The slabs are kept here in one place so they are easy to change if the fares change.
 * Distance = straight pieces between stops x ROAD_FACTOR (roads are not straight).
 */
object Fare {
    private val NON_AC = listOf(Slab(0, 4, 5), Slab(4, 10, 10), Slab(10, -1, 15))
    private val AC = listOf(Slab(0, 4, 10), Slab(4, 8, 15), Slab(8, 12, 20), Slab(12, -1, 25))
    const val ROAD_FACTOR = 1.2

    fun slabs(ac: Boolean): List<Slab> = if (ac) AC else NON_AC

    fun forKm(km: Double, ac: Boolean): Int {
        val list = slabs(ac)
        for (s in list) {
            if (s.toKm < 0 || km <= s.toKm) return s.fare
        }
        return list[list.size - 1].fare
    }

    fun legKm(leg: Leg): Double {
        var m = 0.0
        for (i in 1 until leg.stops.size) {
            val a = leg.stops[i - 1]
            val b = leg.stops[i]
            m += distanceM(a.lat, a.lon, b.lat, b.lon)
        }
        return m * ROAD_FACTOR / 1000.0
    }

    fun legFare(leg: Leg, ac: Boolean, free: Boolean): Int = if (free) 0 else forKm(legKm(leg), ac)

    fun total(legs: List<Leg>, ac: Boolean, free: Boolean): Int = legs.sumOf { legFare(it, ac, free) }

    fun planFare(p: Plan, ac: Boolean, free: Boolean): Int = total(p.legs, ac, free)
}
