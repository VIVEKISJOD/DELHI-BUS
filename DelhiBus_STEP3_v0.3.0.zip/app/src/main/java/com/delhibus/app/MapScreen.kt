package com.delhibus.app

import android.content.Context
import android.graphics.drawable.GradientDrawable
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Polyline
import java.io.File

class MapLine(val stops: List<Stop>, val color: Int)
class Pin(val stop: Stop, val label: String)

object UiColors {
    val Green = Color(0xFF1E8E3E)
    val Red = Color(0xFFD93025)
    val Blue = Color(0xFF1A73E8)
}

// ---------------------------------------------------------------- map

@Composable
fun OsmMap(
    user: Location?,
    follow: Boolean,
    lines: List<MapLine>,
    pins: List<Pin>,
    fit: List<Stop>,
    focus: Stop?,
    youLabel: String,
    modifier: Modifier
) {
    val ctx = LocalContext.current
    val map = remember {
        Configuration.getInstance().userAgentValue = ctx.packageName
        Configuration.getInstance().osmdroidBasePath = File(ctx.cacheDir, "osmdroid")
        Configuration.getInstance().osmdroidTileCache = File(ctx.cacheDir, "osmdroid/tiles")
        MapView(ctx).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(12.0)
            controller.setCenter(GeoPoint(28.6139, 77.2090))
        }
    }
    DisposableEffect(Unit) {
        map.onResume()
        onDispose {
            map.onPause()
            map.onDetach()
        }
    }
    var centered by remember { mutableStateOf(false) }
    LaunchedEffect(user, follow) {
        if (user != null) {
            if (!centered) {
                centered = true
                map.controller.setZoom(16.0)
                map.controller.setCenter(GeoPoint(user.latitude, user.longitude))
            } else if (follow) {
                map.controller.animateTo(GeoPoint(user.latitude, user.longitude))
            }
        }
    }
    LaunchedEffect(focus) {
        if (focus != null) {
            map.controller.setZoom(17.0)
            map.controller.animateTo(GeoPoint(focus.lat, focus.lon))
        }
    }
    LaunchedEffect(fit) {
        if (fit.size > 1) {
            val pts = fit.map { GeoPoint(it.lat, it.lon) }
            map.post { map.zoomToBoundingBox(BoundingBox.fromGeoPoints(pts), true, 120) }
        } else if (fit.size == 1) {
            map.controller.setZoom(16.0)
            map.controller.animateTo(GeoPoint(fit[0].lat, fit[0].lon))
        }
    }
    AndroidView(
        factory = { map },
        modifier = modifier,
        update = { m ->
            m.overlays.clear()
            for (ln in lines) {
                if (ln.stops.size < 2) continue
                val line = Polyline()
                line.setPoints(ln.stops.map { GeoPoint(it.lat, it.lon) })
                line.outlinePaint.color = ln.color
                line.outlinePaint.strokeWidth = 12f
                m.overlays.add(line)
            }
            for (p in pins) {
                val mk = Marker(m)
                mk.position = GeoPoint(p.stop.lat, p.stop.lon)
                mk.title = p.label
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                m.overlays.add(mk)
            }
            if (focus != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(focus.lat, focus.lon)
                mk.title = focus.name
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                m.overlays.add(mk)
            }
            if (user != null) {
                val mk = Marker(m)
                mk.position = GeoPoint(user.latitude, user.longitude)
                mk.title = youLabel
                mk.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                val dot = GradientDrawable()
                dot.shape = GradientDrawable.OVAL
                dot.setColor(android.graphics.Color.parseColor("#1A73E8"))
                dot.setStroke(5, android.graphics.Color.WHITE)
                dot.setSize(40, 40)
                mk.icon = dot
                m.overlays.add(mk)
            }
            m.invalidate()
        }
    )
}

// ---------------------------------------------------------------- small pieces

@Composable
fun BusBadge(number: String) {
    val ctx = LocalContext.current
    val type = remember(number) { BusUi.type(ctx, number) }
    val label = BusUi.typeLabel(type)
    Row(verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(8.dp), color = Color(BusUi.color(number))) {
            Text(
                number,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        if (label != 0) {
            Text("  " + stringResource(label), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
fun TagText(text: String) {
    Surface(shape = RoundedCornerShape(6.dp), color = MaterialTheme.colorScheme.primaryContainer) {
        Text(
            text,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun FareChip(text: String) {
    Surface(shape = RoundedCornerShape(10.dp), color = MaterialTheme.colorScheme.secondaryContainer) {
        Text(
            text,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSecondaryContainer,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun fareText(amount: Int): String =
    if (amount <= 0) stringResource(R.string.fare_free) else stringResource(R.string.fare_rs, amount)

@Composable
fun Dot(color: Color) {
    Box(Modifier.size(12.dp).background(color, CircleShape))
}

@Composable
fun CircleBadge(content: @Composable () -> Unit) {
    Box(
        Modifier.size(44.dp).background(MaterialTheme.colorScheme.primary, CircleShape),
        contentAlignment = Alignment.Center
    ) { content() }
}

/** A rounded white "search pill" like in Google Maps. */
@Composable
fun SearchPill(
    value: String,
    hint: String,
    onChange: (String) -> Unit,
    onFocus: (Boolean) -> Unit,
    modifier: Modifier
) {
    Surface(shape = RoundedCornerShape(28.dp), tonalElevation = 3.dp, shadowElevation = 3.dp, modifier = modifier) {
        Row(
            Modifier.padding(horizontal = 14.dp).height(48.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                if (value.isEmpty()) {
                    Text(
                        hint,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                BasicTextField(
                    value = value,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onSurface),
                    cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                    modifier = Modifier.fillMaxWidth().onFocusChanged { onFocus(it.isFocused) }
                )
            }
            if (value.isNotEmpty()) {
                IconButton(onClick = { onChange("") }, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.Close, contentDescription = null)
                }
            }
        }
    }
}

/** A rounded information bar (icon on the left, two lines of text). */
@Composable
fun InfoBar(
    title: String,
    subtitle: String,
    container: Color,
    onClick: (() -> Unit)?,
    badge: @Composable () -> Unit
) {
    val m = if (onClick != null) Modifier.fillMaxWidth().clickable { onClick() } else Modifier.fillMaxWidth()
    Surface(shape = RoundedCornerShape(20.dp), color = container, modifier = m) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            badge()
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                if (subtitle.isNotEmpty()) {
                    Text(subtitle, style = MaterialTheme.typography.bodyMedium)
                }
            }
            if (onClick != null) {
                Text("›", style = MaterialTheme.typography.headlineSmall)
            }
        }
    }
}

/** One tappable row in a search list. */
@Composable
fun ResultRow(title: String, subtitle: String, highlight: Boolean, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { onClick() }
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(
                title,
                modifier = Modifier.weight(1f),
                fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
                color = if (highlight) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            if (subtitle.isNotEmpty()) {
                Spacer(Modifier.width(8.dp))
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp)
    )
}

private fun startTrip(ctx: Context, legs: List<Leg>, peak: Double): Boolean {
    if (!Perms.isGranted(ctx, Perm.LOCATION)) {
        Toast.makeText(ctx, ctx.getString(R.string.need_location), Toast.LENGTH_LONG).show()
        return false
    }
    val ac = Prefs.bool(ctx, "fare_ac", false)
    val free = Prefs.bool(ctx, "fare_women", false)
    Trip.start(legs, Prefs.int(ctx, "alarm_stops", 2), peak, Fare.total(legs, ac, free))
    TripService.send(ctx, TripService.ACTION_START)
    return true
}

private fun findPlans(rt: Router, sLat: Double, sLon: Double, d: Stop, peak: Double): List<Plan> {
    val fromC = rt.candidatesNear(sLat, sLon, 700.0, 8)
    val toC = rt.candidatesNear(d.lat, d.lon, 400.0, 8)
    return rt.search(fromC, toC, peak)
}

// ---------------------------------------------------------------- main screen

@Composable
fun MapScreen(data: TransitData?, update: UpdateState, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val focusManager = LocalFocusManager.current
    val hindi = Prefs.str(ctx, "lang", "") == "hi"
    val saveMode = Prefs.bool(ctx, "gps_save", false)
    val fareAc = Prefs.bool(ctx, "fare_ac", false)
    val fareFree = Prefs.bool(ctx, "fare_women", false)
    val tick = rememberResumeTick()
    val hasLoc = remember(tick.value) { Perms.isGranted(ctx, Perm.LOCATION) }
    var loc by remember { mutableStateOf<Location?>(null) }

    val router by produceState<Router?>(null, data) {
        value = if (data == null) null else withContext(Dispatchers.Default) {
            try {
                Router(data)
            } catch (e: Exception) {
                null
            }
        }
    }

    var fromStop by remember { mutableStateOf<Stop?>(null) }
    var fromText by remember { mutableStateOf("") }
    var editFrom by remember { mutableStateOf(false) }
    var toText by remember { mutableStateOf("") }
    var toFocused by remember { mutableStateOf(false) }
    var dest by remember { mutableStateOf<Stop?>(null) }
    var route by remember { mutableStateOf<BusRoute?>(null) }
    var routeAlight by remember { mutableStateOf(-1) }
    var plans by remember { mutableStateOf<List<Plan>?>(null) }
    var selected by remember { mutableStateOf(-1) }
    var searching by remember { mutableStateOf(false) }
    var focusStop by remember { mutableStateOf<Stop?>(null) }
    var pending by remember { mutableStateOf<List<Leg>?>(null) }
    var showFare by remember { mutableStateOf(false) }
    val peak = remember { Router.peakFactor() }

    DisposableEffect(hasLoc, saveMode) {
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                loc = location
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Old Android versions still call this")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        if (hasLoc) {
            try {
                val providers = if (saveMode) listOf(LocationManager.NETWORK_PROVIDER)
                else listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                for (pr in providers) {
                    if (lm.isProviderEnabled(pr)) {
                        lm.requestLocationUpdates(pr, 3000L, 0f, listener, Looper.getMainLooper())
                        val known = lm.getLastKnownLocation(pr)
                        if (known != null && loc == null) loc = known
                    }
                }
            } catch (e: SecurityException) {
                // permission was taken away
            }
        }
        onDispose { lm.removeUpdates(listener) }
    }

    LaunchedEffect(Unit) {
        if (update.status == "idle") update.check()
    }

    val tripOn = Trip.active
    val keepOn = tripOn && Prefs.bool(ctx, "keep_on", false)
    val view = LocalView.current
    DisposableEffect(keepOn) {
        view.keepScreenOn = keepOn
        onDispose { view.keepScreenOn = false }
    }

    val gotFix = loc != null
    LaunchedEffect(dest, fromStop, router, gotFix) {
        plans = null
        selected = -1
        val d = dest
        val rt = router
        if (d == null || rt == null) return@LaunchedEffect
        val l = loc
        val fs = fromStop
        val sLat = fs?.lat ?: l?.latitude
        val sLon = fs?.lon ?: l?.longitude
        if (sLat == null || sLon == null) return@LaunchedEffect
        searching = true
        val res = withContext(Dispatchers.Default) {
            try {
                findPlans(rt, sLat, sLon, d, peak)
            } catch (e: Exception) {
                emptyList<Plan>()
            }
        }
        plans = res
        searching = false
    }

    val exitDirections = {
        dest = null
        toText = ""
        plans = null
        selected = -1
        editFrom = false
        route = null
        routeAlight = -1
    }

    BackHandler(enabled = showFare && !tripOn) {
        showFare = false
    }
    BackHandler(enabled = !showFare && !tripOn && (route != null || selected >= 0 || dest != null || toFocused || editFrom)) {
        if (editFrom) {
            editFrom = false
            focusManager.clearFocus()
        } else if (toFocused) {
            toFocused = false
            focusManager.clearFocus()
        } else if (route != null) {
            route = null
            routeAlight = -1
        } else if (selected >= 0) {
            selected = -1
        } else {
            exitDirections()
        }
    }

    val nearbyList = remember(loc?.latitude, loc?.longitude, data) {
        val l = loc
        if (l != null && data != null) data.nearestN(l.latitude, l.longitude, 5) else emptyList()
    }
    val nearest: Pair<Stop, Double>? = nearbyList.firstOrNull()

    // Boarding: ask "which bus?" only when another bus goes the same way.
    val board: (List<Leg>) -> Unit = { legs ->
        if (legs.isNotEmpty()) {
            if (legs[0].alts.isEmpty()) {
                if (startTrip(ctx, legs, peak)) selected = -1
            } else {
                pending = legs
            }
        }
    }

    // ---- what the map shows
    val shown: Plan? = plans?.let { it.getOrNull(if (selected >= 0) selected else 0) }
    val lines = ArrayList<MapLine>()
    val pins = ArrayList<Pin>()
    var fit: List<Stop> = emptyList()
    if (tripOn) {
        val all = Trip.legStops
        val upto = Trip.curIdx + 1
        if (upto >= 2 && upto <= all.size) lines.add(MapLine(all.take(upto), UiColors.Green.toArgb()))
        lines.add(MapLine(Trip.remaining, BusUi.color(Trip.busNumber)))
        val g = Trip.getOff
        if (g != null) pins.add(Pin(g, g.display(hindi)))
    } else if (route != null && data != null) {
        val rs = data.stopsOf(route!!)
        lines.add(MapLine(rs, BusUi.color(route!!.number)))
        fit = rs
        if (rs.isNotEmpty()) pins.add(Pin(rs.first(), rs.first().display(hindi)))
        if (routeAlight in rs.indices) pins.add(Pin(rs[routeAlight], rs[routeAlight].display(hindi)))
    } else if (shown != null) {
        val all = ArrayList<Stop>()
        for (lg in shown.legs) {
            lines.add(MapLine(lg.stops, BusUi.color(lg.route.number)))
            all.addAll(lg.stops)
            pins.add(Pin(lg.stops.first(), lg.stops.first().display(hindi)))
            pins.add(Pin(lg.stops.last(), lg.stops.last().display(hindi)))
        }
        fit = all
    } else if (dest == null && nearest != null) {
        pins.add(Pin(nearest.first, nearest.first.display(hindi)))
    }

    if (showFare && !tripOn) {
        FareScreen(data, router, hindi, loc, peak, onBack = { showFare = false })
    } else {
        BoxWithConstraints(Modifier.fillMaxSize()) {
            val screenH = maxHeight
            val typing = toFocused || editFrom
            val mapH = when {
                tripOn -> screenH * 0.34f
                typing -> 0.dp
                else -> 190.dp
            }
            val d = dest
            val r = route

            Column(Modifier.fillMaxSize()) {
                // ---- top area (search or directions header)
                if (!tripOn) {
                    if (d == null) {
                        Column(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                SearchPill(
                                    value = toText,
                                    hint = stringResource(R.string.search_hint),
                                    onChange = {
                                        toText = it
                                        dest = null
                                        route = null
                                        routeAlight = -1
                                    },
                                    onFocus = { toFocused = it },
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(onClick = onSettings) {
                                    Icon(
                                        Icons.Filled.Settings,
                                        contentDescription = stringResource(R.string.settings),
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                            if (update.status == "available") {
                                Surface(
                                    shape = RoundedCornerShape(14.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp, end = 8.dp).clickable { onSettings() }
                                ) {
                                    Text(
                                        stringResource(R.string.u_banner) + ": " + (update.info?.versionName ?: ""),
                                        modifier = Modifier.padding(12.dp),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                            }
                        }
                    } else {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            tonalElevation = 3.dp,
                            shadowElevation = 3.dp,
                            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { exitDirections() }) {
                                    Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.back_btn))
                                }
                                Column(Modifier.weight(1f).padding(end = 8.dp, top = 6.dp, bottom = 6.dp)) {
                                    if (editFrom) {
                                        SearchPill(
                                            value = fromText,
                                            hint = stringResource(R.string.from_hint2),
                                            onChange = { fromText = it },
                                            onFocus = { },
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    } else {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Dot(UiColors.Blue)
                                            Spacer(Modifier.width(10.dp))
                                            Text(
                                                fromStop?.display(hindi) ?: stringResource(R.string.your_location),
                                                modifier = Modifier.weight(1f),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            TextButton(onClick = {
                                                editFrom = true
                                                fromText = ""
                                            }) { Text(stringResource(R.string.change)) }
                                        }
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 6.dp)) {
                                        Dot(UiColors.Red)
                                        Spacer(Modifier.width(10.dp))
                                        Text(
                                            d.display(hindi),
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.weight(1f),
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // ---- small map card
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = if (mapH > 0.dp) 6.dp else 0.dp)
                        .height(mapH)
                        .clip(RoundedCornerShape(20.dp))
                ) {
                    OsmMap(
                        user = loc,
                        follow = tripOn,
                        lines = lines,
                        pins = pins,
                        fit = fit,
                        focus = if (tripOn) null else focusStop,
                        youLabel = stringResource(R.string.you_are_here),
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // ---- content
                if (tripOn) {
                    TripSheet(hindi, Modifier.weight(1f).fillMaxWidth())
                } else {
                    Column(
                        Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .verticalScroll(rememberScrollState())
                            .padding(start = 12.dp, end = 12.dp, bottom = 16.dp)
                    ) {
                        val q = (if (editFrom) fromText else toText).trim()
                        if (editFrom && d != null && data != null) {
                            ResultRow(stringResource(R.string.use_my_location), "", true) {
                                fromStop = null
                                fromText = ""
                                editFrom = false
                                focusManager.clearFocus()
                            }
                            for (s in data.searchStops(q)) {
                                ResultRow(s.display(hindi), "", false) {
                                    fromStop = s
                                    fromText = s.display(hindi)
                                    editFrom = false
                                    focusManager.clearFocus()
                                }
                            }
                        } else if (d != null) {
                            val pl = plans
                            val sel = selected
                            if (searching || (pl == null && (gotFix || fromStop != null))) {
                                Hint(stringResource(R.string.finding_routes))
                            } else if (pl == null) {
                                Hint(stringResource(R.string.wait_fix))
                            } else if (pl.isEmpty()) {
                                Hint(stringResource(R.string.no_route))
                            } else if (sel >= 0 && sel < pl.size) {
                                PlanDetail(
                                    pl[sel], hindi, peak, fareAc, fareFree,
                                    onBack = { selected = -1 },
                                    onBoard = { legIndex -> board(pl[sel].legs.drop(legIndex)) }
                                )
                            } else {
                                PlanList(pl, hindi, fareAc, fareFree,
                                    onOpen = { i -> selected = i },
                                    onBoard = { i -> board(pl[i].legs) }
                                )
                            }
                        } else if (toFocused && data != null && q.isNotEmpty()) {
                            val rs = remember(q, data) { data.searchRoutes(q) }
                            val ss = remember(q, data) { data.searchStops(q) }
                            if (rs.isEmpty() && ss.isEmpty()) Hint(stringResource(R.string.no_results))
                            if (rs.isNotEmpty()) {
                                SectionTitle(stringResource(R.string.buses))
                                for (b in rs) {
                                    Surface(
                                        shape = RoundedCornerShape(14.dp),
                                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable {
                                            route = b
                                            routeAlight = -1
                                            toFocused = false
                                            focusManager.clearFocus()
                                        }
                                    ) {
                                        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                                            BusBadge(b.number)
                                            Text(
                                                data.routeTitle(b, hindi) + "  ·  " + stringResource(R.string.stops_count, b.stopIds.size),
                                                style = MaterialTheme.typography.bodySmall
                                            )
                                        }
                                    }
                                }
                            }
                            if (ss.isNotEmpty()) {
                                SectionTitle(stringResource(R.string.stops))
                                for (s in ss) {
                                    ResultRow(s.display(hindi), "", false) {
                                        dest = s
                                        toText = s.display(hindi)
                                        toFocused = false
                                        focusManager.clearFocus()
                                    }
                                }
                            }
                        } else if (toFocused && data != null) {
                            SectionTitle(stringResource(R.string.nearby_stands))
                            if (nearbyList.isEmpty()) Hint(stringResource(R.string.locating))
                            for (p in nearbyList) {
                                ResultRow(p.first.display(hindi), p.second.toInt().toString() + " m", false) {
                                    dest = p.first
                                    toText = p.first.display(hindi)
                                    toFocused = false
                                    focusManager.clearFocus()
                                }
                            }
                        } else if (r != null && data != null) {
                            RouteDetail(
                                data, r, hindi, routeAlight,
                                onPickStop = { i, s ->
                                    routeAlight = i
                                    focusStop = s
                                },
                                onClose = {
                                    route = null
                                    routeAlight = -1
                                },
                                onBoard = {
                                    val rt = router
                                    if (rt != null && routeAlight > 0) {
                                        val l = loc
                                        val bp = if (l != null) rt.nearestPosOnRoute(r, l.latitude, l.longitude, routeAlight) else 0
                                        val b = if (bp < routeAlight) bp else 0
                                        board(listOf(rt.makeLeg(r, b, routeAlight, 0)))
                                    }
                                }
                            )
                        } else {
                            HomeContent(
                                data, nearbyList, loc != null, hasLoc, hindi,
                                onFare = { showFare = true },
                                onShow = { focusStop = it }
                            )
                        }
                    }
                }
            }
        }
    }

    // ---- "which bus are you on?" (only when another bus goes the same way)
    val pend = pending
    if (pend != null && pend.isNotEmpty()) {
        val first = pend[0]
        AlertDialog(
            onDismissRequest = { pending = null },
            title = { Text(stringResource(R.string.confirm_title)) },
            text = {
                Column {
                    Text(
                        first.stops.first().display(hindi) + " → " + first.stops.last().display(hindi),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (first.alts.isNotEmpty()) {
                        Gap(8)
                        for (a in first.alts) {
                            OutlinedButton(
                                onClick = {
                                    val rt = router
                                    val swapped = rt?.legWithNumber(a, first.stops.first().id, first.stops.last().id, first.walkBeforeM)
                                    if (swapped != null) {
                                        val ok = startTrip(ctx, listOf(swapped) + pend.drop(1), peak)
                                        if (ok) {
                                            pending = null
                                            selected = -1
                                        }
                                    }
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) { Text(stringResource(R.string.confirm_other, a)) }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val ok = startTrip(ctx, pend, peak)
                    if (ok) {
                        pending = null
                        selected = -1
                    }
                }) { Text(stringResource(R.string.confirm_yes, first.route.number)) }
            },
            dismissButton = {
                TextButton(onClick = { pending = null }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

private fun Color.toArgb(): Int = android.graphics.Color.argb(
    (alpha * 255f).toInt(), (red * 255f).toInt(), (green * 255f).toInt(), (blue * 255f).toInt()
)

@Composable
fun Hint(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 14.dp, horizontal = 4.dp)
    )
}

// ---------------------------------------------------------------- home

@Composable
fun HomeContent(
    data: TransitData?,
    nearby: List<Pair<Stop, Double>>,
    hasFix: Boolean,
    hasPerm: Boolean,
    hindi: Boolean,
    onFare: () -> Unit,
    onShow: (Stop) -> Unit
) {
    val nearest = nearby.firstOrNull()
    Gap(4)
    // nearest bus stand
    if (!hasPerm) {
        InfoBar(
            stringResource(R.string.nearest_stand), stringResource(R.string.no_location),
            MaterialTheme.colorScheme.errorContainer, null
        ) { CircleBadge { Icon(Icons.Filled.Place, contentDescription = null, tint = Color.White) } }
    } else if (nearest == null || !hasFix) {
        InfoBar(
            stringResource(R.string.nearest_stand), stringResource(R.string.locating),
            MaterialTheme.colorScheme.primaryContainer, null
        ) { CircleBadge { Icon(Icons.Filled.Place, contentDescription = null, tint = Color.White) } }
    } else {
        val m = nearest.second.toInt()
        val walk = Math.max(1, Math.round(nearest.second / Router.WALK_M_PER_MIN).toInt())
        InfoBar(
            nearest.first.display(hindi),
            stringResource(R.string.away_walk, m, walk),
            MaterialTheme.colorScheme.primaryContainer,
            { onShow(nearest.first) }
        ) { CircleBadge { Icon(Icons.Filled.Place, contentDescription = null, tint = Color.White) } }
    }
    Gap(10)
    // fare calculator
    InfoBar(
        stringResource(R.string.fare_title), stringResource(R.string.fare_sub),
        MaterialTheme.colorScheme.secondaryContainer, onFare
    ) {
        CircleBadge { Text("₹", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleLarge) }
    }
    // nearby stands
    if (nearby.size > 1 && hasFix) {
        SectionTitle(stringResource(R.string.nearby_stands))
        for (p in nearby.drop(1)) {
            ResultRow(p.first.display(hindi), p.second.toInt().toString() + " m", false) { onShow(p.first) }
        }
    }
    if (data != null) {
        Gap(10)
        Text(stringResource(R.string.data_info, data.stops.size, data.routes.size), style = MaterialTheme.typography.bodySmall)
        if (data.demo) {
            Text(
                stringResource(R.string.demo_banner),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.error
            )
        }
    }
}

// ---------------------------------------------------------------- plans

@Composable
fun PlanList(
    plans: List<Plan>,
    hindi: Boolean,
    ac: Boolean,
    free: Boolean,
    onOpen: (Int) -> Unit,
    onBoard: (Int) -> Unit
) {
    for ((i, p) in plans.withIndex()) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            tonalElevation = 2.dp,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onOpen(i) }
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        stringResource(R.string.plan_min, p.totalMin),
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = UiColors.Green
                    )
                    Spacer(Modifier.width(8.dp))
                    if (p.fastest) TagText(stringResource(R.string.tag_fastest))
                    if (p.fewest) {
                        Spacer(Modifier.width(4.dp))
                        TagText(stringResource(R.string.tag_fewest))
                    }
                    Spacer(Modifier.weight(1f))
                    FareChip(fareText(Fare.planFare(p, ac, free)))
                }
                Gap(8)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    for ((n, lg) in p.legs.withIndex()) {
                        if (n > 0) Text("  ›  ")
                        BusBadge(lg.route.number)
                    }
                }
                Gap(6)
                Text(
                    stringResource(R.string.plan_summary, p.changes, p.totalStops, p.walkStartM + p.walkEndM),
                    style = MaterialTheme.typography.bodySmall
                )
                Gap(10)
                Button(onClick = { onBoard(i) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.plan_board))
                }
            }
        }
    }
    Gap(4)
    Text(stringResource(R.string.est_note), style = MaterialTheme.typography.bodySmall)
}

@Composable
fun PlanDetail(
    plan: Plan,
    hindi: Boolean,
    peak: Double,
    ac: Boolean,
    free: Boolean,
    onBack: () -> Unit,
    onBoard: (Int) -> Unit
) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            stringResource(R.string.plan_min, plan.totalMin),
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = UiColors.Green
        )
        Spacer(Modifier.width(8.dp))
        FareChip(fareText(Fare.planFare(plan, ac, free)))
        Spacer(Modifier.weight(1f))
        OutlinedButton(onClick = onBack) { Text(stringResource(R.string.back_plans)) }
    }
    Gap(8)
    if (plan.walkStartM > 0 && plan.legs.isNotEmpty()) {
        Hint(stringResource(R.string.walk_to, plan.walkStartM, plan.legs[0].stops.first().display(hindi)))
    }
    for ((i, lg) in plan.legs.withIndex()) {
        if (i > 0 && lg.walkBeforeM > 0) {
            Hint(stringResource(R.string.walk_between, lg.walkBeforeM))
        }
        Surface(
            shape = RoundedCornerShape(20.dp),
            tonalElevation = 2.dp,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    BusBadge(lg.route.number)
                    Spacer(Modifier.weight(1f))
                    FareChip(fareText(Fare.legFare(lg, ac, free)))
                }
                Gap(8)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(UiColors.Blue)
                    Spacer(Modifier.width(10.dp))
                    Text(stringResource(R.string.board_at, lg.stops.first().display(hindi)))
                }
                Gap(4)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Dot(UiColors.Red)
                    Spacer(Modifier.width(10.dp))
                    Text(stringResource(R.string.getoff_at, lg.stops.last().display(hindi)))
                }
                Gap(6)
                Text(stringResource(R.string.leg_info, lg.stopCount, lg.rideMin(peak)), style = MaterialTheme.typography.bodySmall)
                if (lg.alts.isNotEmpty()) {
                    Text(stringResource(R.string.same_route, lg.alts.joinToString(", ")), style = MaterialTheme.typography.bodySmall)
                }
                Gap(10)
                Button(onClick = { onBoard(i) }, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.boarded_btn))
                }
            }
        }
    }
    if (plan.walkEndM > 0) {
        Hint(stringResource(R.string.walk_end, plan.walkEndM))
    }
    Text(stringResource(R.string.est_note), style = MaterialTheme.typography.bodySmall)
}

@Composable
fun RouteDetail(
    data: TransitData,
    r: BusRoute,
    hindi: Boolean,
    alight: Int,
    onPickStop: (Int, Stop) -> Unit,
    onClose: () -> Unit,
    onBoard: () -> Unit
) {
    Gap(6)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            BusBadge(r.number)
            Text(data.routeTitle(r, hindi), style = MaterialTheme.typography.bodySmall)
        }
        OutlinedButton(onClick = onClose) { Text(stringResource(R.string.close)) }
    }
    Gap(8)
    val stops = data.stopsOf(r)
    if (alight in stops.indices) {
        Text(stringResource(R.string.getoff_at, stops[alight].display(hindi)), fontWeight = FontWeight.Bold)
        Gap(6)
        Button(onClick = onBoard, modifier = Modifier.fillMaxWidth()) { Text(stringResource(R.string.boarded_btn)) }
    } else {
        Hint(stringResource(R.string.route_tap_hint))
    }
    Gap(6)
    for ((i, s) in stops.withIndex()) {
        ResultRow((i + 1).toString() + ".  " + s.display(hindi), "", i == alight) { onPickStop(i, s) }
    }
}

// ---------------------------------------------------------------- fare calculator

@Composable
fun FareScreen(
    data: TransitData?,
    router: Router?,
    hindi: Boolean,
    loc: Location?,
    peak: Double,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val focusManager = LocalFocusManager.current
    var ac by remember { mutableStateOf(Prefs.bool(ctx, "fare_ac", false)) }
    var free by remember { mutableStateOf(Prefs.bool(ctx, "fare_women", false)) }
    var fromStop by remember { mutableStateOf<Stop?>(null) }
    var toStop by remember { mutableStateOf<Stop?>(null) }
    var fromText by remember { mutableStateOf("") }
    var toText by remember { mutableStateOf("") }
    var active by remember { mutableStateOf(0) }
    var plans by remember { mutableStateOf<List<Plan>?>(null) }
    var busy by remember { mutableStateOf(false) }
    val gotFix = loc != null

    LaunchedEffect(fromStop, toStop, router, gotFix) {
        plans = null
        val d = toStop
        val rt = router
        if (d == null || rt == null) return@LaunchedEffect
        val l = loc
        val fs = fromStop
        val sLat = fs?.lat ?: l?.latitude
        val sLon = fs?.lon ?: l?.longitude
        if (sLat == null || sLon == null) return@LaunchedEffect
        busy = true
        val res = withContext(Dispatchers.Default) {
            try {
                findPlans(rt, sLat, sLon, d, peak)
            } catch (e: Exception) {
                emptyList<Plan>()
            }
        }
        plans = res
        busy = false
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 4.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = stringResource(R.string.back_btn))
            }
            Text(stringResource(R.string.fare_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(start = 12.dp, end = 12.dp, bottom = 16.dp)
        ) {
            Gap(6)
            SearchPill(
                value = fromText,
                hint = stringResource(R.string.fare_from_hint),
                onChange = {
                    fromText = it
                    fromStop = null
                },
                onFocus = { if (it) active = 1 },
                modifier = Modifier.fillMaxWidth()
            )
            Gap(8)
            SearchPill(
                value = toText,
                hint = stringResource(R.string.fare_to_hint),
                onChange = {
                    toText = it
                    toStop = null
                },
                onFocus = { if (it) active = 2 },
                modifier = Modifier.fillMaxWidth()
            )
            Gap(10)
            val q = (if (active == 1) fromText else toText).trim()
            val picking = active != 0 && q.isNotEmpty() && data != null &&
                ((active == 1 && fromStop == null) || (active == 2 && toStop == null))
            if (picking && data != null) {
                for (s in data.searchStops(q)) {
                    ResultRow(s.display(hindi), "", false) {
                        if (active == 1) {
                            fromStop = s
                            fromText = s.display(hindi)
                        } else {
                            toStop = s
                            toText = s.display(hindi)
                        }
                        active = 0
                        focusManager.clearFocus()
                    }
                }
            } else {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ChoiceButton(stringResource(R.string.bt_nonac), !ac) { ac = false }
                    ChoiceButton(stringResource(R.string.bt_ac), ac) { ac = true }
                }
                Gap(8)
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(R.string.fare_women), modifier = Modifier.weight(1f))
                    Switch(checked = free, onCheckedChange = { free = it })
                }
                val pl = plans
                if (toStop == null) {
                    Hint(stringResource(R.string.fare_pick_hint))
                } else if (busy || (pl == null && (gotFix || fromStop != null))) {
                    Hint(stringResource(R.string.finding_routes))
                } else if (pl == null) {
                    Hint(stringResource(R.string.wait_fix))
                } else if (pl.isEmpty()) {
                    Hint(stringResource(R.string.no_route))
                } else {
                    for (p in pl.take(3)) {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            tonalElevation = 2.dp,
                            shadowElevation = 2.dp,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)
                        ) {
                            Column(Modifier.padding(14.dp)) {
                                for (lg in p.legs) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                                        BusBadge(lg.route.number)
                                        Spacer(Modifier.width(10.dp))
                                        Text(
                                            stringResource(R.string.fare_leg, lg.stopCount, Fare.legKm(lg)),
                                            style = MaterialTheme.typography.bodySmall,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(fareText(Fare.legFare(lg, ac, free)), fontWeight = FontWeight.Bold)
                                    }
                                }
                                Gap(6)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        stringResource(R.string.fare_total),
                                        style = MaterialTheme.typography.titleMedium,
                                        modifier = Modifier.weight(1f)
                                    )
                                    Text(
                                        fareText(Fare.planFare(p, ac, free)),
                                        style = MaterialTheme.typography.headlineSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = UiColors.Green
                                    )
                                }
                            }
                        }
                    }
                }
                SectionTitle(stringResource(R.string.fare_slabs))
                for (s in Fare.slabs(ac)) {
                    val label = if (s.fromKm == 0) stringResource(R.string.slab_upto, s.toKm)
                    else if (s.toKm < 0) stringResource(R.string.slab_above, s.fromKm)
                    else stringResource(R.string.slab_between, s.fromKm, s.toKm)
                    ResultRow(label, stringResource(R.string.fare_rs, s.fare), false) { }
                }
                Gap(8)
                Text(stringResource(R.string.fare_women_note), style = MaterialTheme.typography.bodySmall)
                Gap(4)
                Text(stringResource(R.string.fare_note), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ---------------------------------------------------------------- trip screen

@Composable
fun StatBox(label: String, value: String, modifier: Modifier) {
    Surface(shape = RoundedCornerShape(14.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = modifier) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
            Text(
                value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
                maxLines = 1
            )
        }
    }
}

@Composable
fun StopNode(reached: Boolean, current: Boolean, next: Boolean, dest: Boolean) {
    Box(Modifier.size(26.dp), contentAlignment = Alignment.Center) {
        if (current) {
            Box(Modifier.size(26.dp).background(UiColors.Green.copy(alpha = 0.25f), CircleShape))
        }
        if (reached) {
            Box(Modifier.size(20.dp).background(UiColors.Green, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            }
        } else if (dest) {
            Box(Modifier.size(20.dp).background(UiColors.Red, CircleShape), contentAlignment = Alignment.Center) {
                Box(Modifier.size(8.dp).background(Color.White, CircleShape))
            }
        } else if (next) {
            Box(
                Modifier
                    .size(18.dp)
                    .background(MaterialTheme.colorScheme.surface, CircleShape)
                    .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
            )
        } else {
            Box(Modifier.size(12.dp).border(2.dp, MaterialTheme.colorScheme.outline, CircleShape))
        }
    }
}

@Composable
fun StopRow(i: Int, s: Stop, cur: Int, last: Int, hindi: Boolean) {
    val reached = i <= cur
    val current = i == cur
    val next = i == cur + 1
    val isLast = i == last
    val lineOff = MaterialTheme.colorScheme.outlineVariant
    Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min)) {
        Column(Modifier.width(30.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier
                    .width(3.dp)
                    .weight(1f)
                    .background(if (i == 0) Color.Transparent else if (reached) UiColors.Green else lineOff)
            )
            StopNode(reached, current, next, isLast)
            Box(
                Modifier
                    .width(3.dp)
                    .weight(1f)
                    .background(if (isLast) Color.Transparent else if (i < cur) UiColors.Green else lineOff)
            )
        }
        Row(
            Modifier.weight(1f).padding(start = 10.dp, top = 10.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                s.display(hindi),
                fontWeight = if (current || next || isLast) FontWeight.Bold else FontWeight.Normal,
                color = if (current) UiColors.Green
                else if (reached) MaterialTheme.colorScheme.onSurfaceVariant
                else MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.weight(1f, fill = false)
            )
            if (next) {
                Spacer(Modifier.width(8.dp))
                TagText(stringResource(R.string.tag_next))
            }
            if (isLast && !reached) {
                Spacer(Modifier.width(8.dp))
                TagText(stringResource(R.string.tag_getoff))
            }
        }
    }
}

@Composable
fun TripSheet(hindi: Boolean, modifier: Modifier) {
    val ctx = LocalContext.current
    val off = Trip.getOff
    val stops = Trip.legStops
    val cur = Trip.curIdx
    val lastIdx = Math.max(0, stops.size - 1)
    val listState = rememberLazyListState()
    LaunchedEffect(cur, Trip.legNo) {
        if (stops.isNotEmpty()) listState.animateScrollToItem(Math.max(0, cur - 1))
    }
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        tonalElevation = 3.dp,
        shadowElevation = 8.dp
    ) {
        Column(Modifier.fillMaxSize().padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 10.dp)) {
            when (Trip.phase) {
                Phase.CHANGE -> {
                    Text(stringResource(R.string.trip_change_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        stringResource(R.string.trip_change_text, off?.display(hindi) ?: "", Trip.nextBus ?: ""),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Gap(8)
                    Button(onClick = { TripService.send(ctx, TripService.ACTION_NEXT) }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.trip_change_btn, Trip.nextBus ?: ""))
                    }
                }
                Phase.DONE -> {
                    Text(stringResource(R.string.trip_arrived_title), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(
                        stringResource(R.string.trip_arrived_text, off?.display(hindi) ?: ""),
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Gap(8)
                    Button(onClick = { TripService.send(ctx, TripService.ACTION_STOP) }, modifier = Modifier.fillMaxWidth()) {
                        Text(stringResource(R.string.trip_ok))
                    }
                }
                else -> {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        BusBadge(Trip.busNumber)
                        if (Trip.legTotal > 1) {
                            Spacer(Modifier.width(10.dp))
                            Text(
                                stringResource(R.string.trip_bus_of, Trip.legNo, Trip.legTotal),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }
                    }
                    Text(
                        stringResource(R.string.trip_to, off?.display(hindi) ?: ""),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Gap(6)
                    Text(
                        stringResource(R.string.trip_next_label),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        Trip.nextStop?.display(hindi) ?: (off?.display(hindi) ?: ""),
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Gap(10)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatBox(stringResource(R.string.stat_left), Trip.stopsLeft.toString(), Modifier.weight(1f))
                        StatBox(stringResource(R.string.stat_time), stringResource(R.string.plan_min, Trip.minutesLeft), Modifier.weight(1f))
                        StatBox(stringResource(R.string.stat_fare), fareText(Trip.fareRs), Modifier.weight(1f))
                    }
                }
            }
            Gap(10)
            val frac = if (lastIdx > 0) (cur.toFloat() / lastIdx.toFloat()).coerceIn(0f, 1f) else 0f
            LinearProgressIndicator(
                progress = frac,
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                color = UiColors.Green,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )
            Gap(4)
            Text(
                stringResource(R.string.trip_progress, cur, lastIdx),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Gap(4)
            LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState) {
                itemsIndexed(stops) { i, s ->
                    StopRow(i, s, cur, lastIdx, hindi)
                }
            }
            Gap(6)
            if (Trip.ringing) {
                Button(
                    onClick = { TripService.send(ctx, TripService.ACTION_STOP_ALARM) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.trip_stop_alarm)) }
                Gap(6)
            }
            if (Trip.phase != Phase.DONE) {
                OutlinedButton(
                    onClick = { TripService.send(ctx, TripService.ACTION_STOP) },
                    modifier = Modifier.fillMaxWidth()
                ) { Text(stringResource(R.string.trip_off_btn)) }
            }
        }
    }
}
