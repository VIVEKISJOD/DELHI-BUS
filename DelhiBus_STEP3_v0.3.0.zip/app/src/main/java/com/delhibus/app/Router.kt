package com.delhibus.app

import java.util.Calendar
import kotlin.math.max
import kotlin.math.min

/** A place near the user's start or end point, with the walking distance to it. */
class Cand(val stop: Stop, val walkM: Int)

/** One bus ride inside a plan. */
class Leg(
    val route: BusRoute,
    val board: Int,
    val alight: Int,
    val stops: List<Stop>,
    val cum: DoubleArray,
    val walkBeforeM: Int,
    val alts: List<String>
) {
    val stopCount: Int get() = stops.size - 1
    fun rideMin(peak: Double): Int = max(1, Math.round(cum[cum.size - 1] * peak).toInt())
}

class Plan(
    val legs: List<Leg>,
    val walkStartM: Int,
    val walkEndM: Int,
    val totalMin: Int,
    var fastest: Boolean,
    var fewest: Boolean
) {
    val changes: Int get() = legs.size - 1
    val totalStops: Int get() = legs.sumOf { it.stopCount }
}

/**
 * Route finder (RAPTOR-like, rounds = number of buses used). Runs fully on the phone.
 * Time is an ESTIMATE from stop distances, average bus speed, waiting and a peak-hour factor.
 */
class Router(private val data: TransitData) {

    companion object {
        const val MOVE_M_PER_MIN = 420.0
        const val DWELL_MIN = 0.4
        const val DETOUR = 1.3
        const val WAIT_MIN = 5.0
        const val WALK_M_PER_MIN = 75.0
        const val FOOT_LINK_M = 250.0
        const val MAX_RIDES = 3
        private const val INF = 1.0e9

        fun peakFactor(): Double {
            val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
            return if ((h in 8..10) || (h in 17..19)) 1.3 else 1.0
        }

        fun cumulative(stops: List<Stop>): DoubleArray {
            val c = DoubleArray(stops.size)
            for (i in 1 until stops.size) {
                val d = distanceM(stops[i - 1].lat, stops[i - 1].lon, stops[i].lat, stops[i].lon) * DETOUR
                c[i] = c[i - 1] + d / MOVE_M_PER_MIN + DWELL_MIN
            }
            return c
        }
    }

    private val stopList: List<Stop> = data.stops.values.toList()
    private val idx = HashMap<String, Int>()
    private val sLat: DoubleArray
    private val sLon: DoubleArray

    private val rIds: List<BusRoute> = data.routes
    private val rStops: Array<IntArray>
    private val rCum: Array<DoubleArray>

    private val srRoute: Array<IntArray>
    private val srPos: Array<IntArray>

    private val nearIdx: Array<IntArray>
    private val nearDist: Array<IntArray>

    init {
        for ((i, s) in stopList.withIndex()) idx[s.id] = i
        sLat = DoubleArray(stopList.size) { stopList[it].lat }
        sLon = DoubleArray(stopList.size) { stopList[it].lon }

        val rs = ArrayList<IntArray>()
        val rc = ArrayList<DoubleArray>()
        for (r in rIds) {
            val ids = r.stopIds.mapNotNull { idx[it] }
            rs.add(ids.toIntArray())
            rc.add(cumulative(ids.map { stopList[it] }))
        }
        rStops = rs.toTypedArray()
        rCum = rc.toTypedArray()

        val tmpR = Array(stopList.size) { ArrayList<Int>() }
        val tmpP = Array(stopList.size) { ArrayList<Int>() }
        for (ri in rStops.indices) {
            for ((pos, s) in rStops[ri].withIndex()) {
                tmpR[s].add(ri)
                tmpP[s].add(pos)
            }
        }
        srRoute = Array(stopList.size) { tmpR[it].toIntArray() }
        srPos = Array(stopList.size) { tmpP[it].toIntArray() }

        val nI = Array(stopList.size) { ArrayList<Int>() }
        val nD = Array(stopList.size) { ArrayList<Int>() }
        val dLat = FOOT_LINK_M / 111000.0 * 1.2
        val dLon = FOOT_LINK_M / 98000.0 * 1.2
        for (a in stopList.indices) {
            for (b in a + 1 until stopList.size) {
                if (Math.abs(sLat[a] - sLat[b]) > dLat || Math.abs(sLon[a] - sLon[b]) > dLon) continue
                val d = distanceM(sLat[a], sLon[a], sLat[b], sLon[b])
                if (d <= FOOT_LINK_M) {
                    nI[a].add(b); nD[a].add(d.toInt())
                    nI[b].add(a); nD[b].add(d.toInt())
                }
            }
        }
        nearIdx = Array(stopList.size) { nI[it].toIntArray() }
        nearDist = Array(stopList.size) { nD[it].toIntArray() }
    }

    /** Stops around a point, nearest first. Always returns at least the nearest stop if there is any. */
    fun candidatesNear(lat: Double, lon: Double, maxM: Double, maxN: Int): List<Cand> {
        val all = ArrayList<Cand>()
        for (s in stopList) {
            val d = distanceM(lat, lon, s.lat, s.lon)
            all.add(Cand(s, d.toInt()))
        }
        all.sortBy { it.walkM }
        val out = all.filter { it.walkM <= maxM }.take(maxN)
        if (out.isEmpty() && all.isNotEmpty()) return listOf(all[0])
        return out
    }

    /** Routes (other than the leg's own) that also go from the same boarding stop to the same getting-off stop. */
    private fun alternatives(boardStop: Int, alightStop: Int, self: Int): List<String> {
        val out = LinkedHashSet<String>()
        for (k in srRoute[boardStop].indices) {
            val r = srRoute[boardStop][k]
            if (r == self) continue
            val pos = srPos[boardStop][k]
            val seq = rStops[r]
            for (j in pos + 1 until seq.size) {
                if (seq[j] == alightStop) {
                    out.add(rIds[r].number)
                    break
                }
            }
            if (out.size >= 6) break
        }
        return out.toList()
    }

    fun makeLeg(route: BusRoute, board: Int, alight: Int, walkBeforeM: Int): Leg {
        val ri = rIds.indexOf(route)
        val ids = rStops[ri]
        val seg = (board..alight).map { stopList[ids[it]] }
        val cum = cumulative(seg)
        val alts = alternatives(ids[board], ids[alight], ri)
        return Leg(route, board, alight, seg, cum, walkBeforeM, alts)
    }

    /** Same ride but on another bus number that also goes from the boarding stop to the getting-off stop. */
    fun legWithNumber(number: String, boardStopId: String, alightStopId: String, walkBeforeM: Int): Leg? {
        for (r in rIds) {
            if (r.number != number) continue
            val b = r.stopIds.indexOf(boardStopId)
            if (b < 0) continue
            var a = -1
            for (j in b + 1 until r.stopIds.size) {
                if (r.stopIds[j] == alightStopId) {
                    a = j
                    break
                }
            }
            if (a > b) return makeLeg(r, b, a, walkBeforeM)
        }
        return null
    }

    /** Position (index in the route) of the stop of this route nearest to a point. */
    fun nearestPosOnRoute(route: BusRoute, lat: Double, lon: Double, before: Int): Int {
        val ri = rIds.indexOf(route)
        val ids = rStops[ri]
        var best = 0
        var bestD = Double.MAX_VALUE
        for (p in 0 until min(ids.size, max(1, before))) {
            val s = stopList[ids[p]]
            val d = distanceM(lat, lon, s.lat, s.lon)
            if (d < bestD) {
                bestD = d
                best = p
            }
        }
        return best
    }

    private class Parent(rounds: Int, n: Int) {
        val type = Array(rounds) { IntArray(n) }
        val route = Array(rounds) { IntArray(n) }
        val board = Array(rounds) { IntArray(n) }
        val alight = Array(rounds) { IntArray(n) }
        val prev = Array(rounds) { IntArray(n) }
        val walk = Array(rounds) { IntArray(n) }
    }

    fun search(from: List<Cand>, to: List<Cand>, peak: Double): List<Plan> {
        val n = stopList.size
        if (n == 0 || from.isEmpty() || to.isEmpty()) return emptyList()
        val rounds = MAX_RIDES + 1
        val tau = Array(rounds) { DoubleArray(n) { INF } }
        val best = DoubleArray(n) { INF }
        val par = Parent(rounds, n)

        var marked = ArrayList<Int>()
        for (c in from) {
            val i = idx[c.stop.id] ?: continue
            val t = c.walkM / WALK_M_PER_MIN
            if (t < tau[0][i]) {
                tau[0][i] = t
                best[i] = t
                par.type[0][i] = 1
                par.walk[0][i] = c.walkM
                marked.add(i)
            }
        }
        marked = footpaths(0, marked, tau, best, par)

        val results = ArrayList<Plan>()
        var bestTotal = INF
        val q = IntArray(rStops.size)

        for (k in 1..MAX_RIDES) {
            for (i in 0 until n) tau[k][i] = tau[k - 1][i]
            java.util.Arrays.fill(q, -1)
            for (s in marked) {
                for (j in srRoute[s].indices) {
                    val r = srRoute[s][j]
                    val p = srPos[s][j]
                    if (q[r] == -1 || p < q[r]) q[r] = p
                }
            }
            val newMarked = ArrayList<Int>()
            val inNew = BooleanArray(n)
            for (r in rStops.indices) {
                if (q[r] < 0) continue
                val seq = rStops[r]
                val cum = rCum[r]
                var bPos = -1
                var bTime = 0.0
                for (j in q[r] until seq.size) {
                    val s = seq[j]
                    if (bPos >= 0) {
                        val t = bTime + (cum[j] - cum[bPos]) * peak
                        if (t < best[s]) {
                            best[s] = t
                            tau[k][s] = t
                            par.type[k][s] = 2
                            par.route[k][s] = r
                            par.board[k][s] = bPos
                            par.alight[k][s] = j
                            par.prev[k][s] = seq[bPos]
                            if (!inNew[s]) {
                                inNew[s] = true
                                newMarked.add(s)
                            }
                        }
                    }
                    val before = tau[k - 1][s]
                    if (before < INF) {
                        val cand = before + WAIT_MIN
                        if (bPos < 0 || cand < bTime + (cum[j] - cum[bPos]) * peak) {
                            bPos = j
                            bTime = cand
                        }
                    }
                }
            }
            marked = footpaths(k, newMarked, tau, best, par)

            var bi = -1
            var bt = INF
            var bw = 0
            for (c in to) {
                val i = idx[c.stop.id] ?: continue
                if (tau[k][i] >= INF) continue
                val total = tau[k][i] + c.walkM / WALK_M_PER_MIN
                if (total < bt) {
                    bt = total
                    bi = i
                    bw = c.walkM
                }
            }
            if (bi >= 0 && bt < bestTotal - 1.0) {
                val plan = trace(k, bi, par, bw, bt, peak)
                if (plan != null && plan.legs.isNotEmpty()) {
                    bestTotal = bt
                    results.add(plan)
                }
            }
            if (marked.isEmpty()) break
        }
        if (results.isNotEmpty()) {
            results[0].fewest = true
            var fastest = results[0]
            for (p in results) if (p.totalMin < fastest.totalMin) fastest = p
            fastest.fastest = true
        }
        return results
    }

    private fun footpaths(k: Int, marked: ArrayList<Int>, tau: Array<DoubleArray>, best: DoubleArray, par: Parent): ArrayList<Int> {
        val out = ArrayList<Int>(marked)
        val seen = HashSet<Int>(marked)
        for (s in marked) {
            val base = tau[k][s]
            for (z in nearIdx[s].indices) {
                val j = nearIdx[s][z]
                val t = base + nearDist[s][z] / WALK_M_PER_MIN
                if (t < best[j]) {
                    best[j] = t
                    tau[k][j] = t
                    par.type[k][j] = 3
                    par.prev[k][j] = s
                    par.walk[k][j] = nearDist[s][z]
                    if (seen.add(j)) out.add(j)
                }
            }
        }
        return out
    }

    private class Piece(val route: Int, val board: Int, val alight: Int, val boardStop: Int, val alightStop: Int)

    private fun trace(k0: Int, dest: Int, par: Parent, walkEnd: Int, total: Double, peak: Double): Plan? {
        val pieces = ArrayList<Piece>()
        var k = k0
        var s = dest
        var walkStart = 0
        var guard = 0
        while (guard++ < 200) {
            while (k > 0 && par.type[k][s] == 0) k--
            when (par.type[k][s]) {
                1 -> {
                    walkStart = par.walk[0][s]
                    break
                }
                2 -> {
                    pieces.add(Piece(par.route[k][s], par.board[k][s], par.alight[k][s], par.prev[k][s], s))
                    s = par.prev[k][s]
                    k--
                }
                3 -> {
                    s = par.prev[k][s]
                }
                else -> return null
            }
        }
        pieces.reverse()
        // walking between two buses is worked out from the stop positions
        val legs = ArrayList<Leg>()
        var prevAlightStop = -1
        for ((n, p) in pieces.withIndex()) {
            val wb = if (n == 0) 0 else distanceM(sLat[prevAlightStop], sLon[prevAlightStop], sLat[p.boardStop], sLon[p.boardStop]).toInt()
            legs.add(makeLeg(rIds[p.route], p.board, p.alight, if (p.boardStop == prevAlightStop) 0 else wb))
            prevAlightStop = p.alightStop
        }
        return Plan(legs, walkStart, walkEnd, Math.round(total).toInt(), false, false)
    }
}
