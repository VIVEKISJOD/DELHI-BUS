package com.delhibus.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** The running trip. The screen and the trip service both read and write this one object. */
object Trip {
    var engine: TripEngine? = null

    var active by mutableStateOf(false)
    var phase by mutableStateOf(Phase.IDLE)
    var busNumber by mutableStateOf("")
    var nextStop by mutableStateOf<Stop?>(null)
    var getOff by mutableStateOf<Stop?>(null)
    var stopsLeft by mutableStateOf(0)
    var minutesLeft by mutableStateOf(0)
    var nextBus by mutableStateOf<String?>(null)
    var ringing by mutableStateOf(false)
    var remaining by mutableStateOf<List<Stop>>(emptyList())

    /** All stops of the bus you are on, and how far you are (index of the last stop reached). */
    var legStops by mutableStateOf<List<Stop>>(emptyList())
    var curIdx by mutableStateOf(0)
    var legNo by mutableStateOf(1)
    var legTotal by mutableStateOf(1)

    /** Estimated fare of the whole trip in rupees. 0 means free. */
    var fareRs by mutableStateOf(0)

    fun start(legs: List<Leg>, alarmStops: Int, peak: Double, fare: Int = 0) {
        if (legs.isEmpty()) return
        engine = TripEngine(legs, alarmStops, peak)
        active = true
        ringing = false
        fareRs = fare
        sync()
    }

    fun sync() {
        val e = engine ?: return
        phase = e.phase
        busNumber = e.leg.route.number
        nextStop = e.nextStop
        getOff = e.getOffStop
        stopsLeft = e.stopsLeft
        minutesLeft = e.minutesLeft()
        nextBus = e.nextLeg?.route?.number
        remaining = e.leg.stops.drop(e.cur)
        legStops = e.leg.stops
        curIdx = e.cur
        legNo = e.legIdx + 1
        legTotal = e.legs.size
    }

    fun onLocation(lat: Double, lon: Double, acc: Float): Boolean {
        val e = engine ?: return false
        val changed = e.onLocation(lat, lon, acc)
        if (changed) sync()
        return changed
    }

    fun boardNext() {
        engine?.boardNext()
        sync()
    }

    fun finish() {
        engine = null
        active = false
        ringing = false
        phase = Phase.IDLE
        nextStop = null
        getOff = null
        remaining = emptyList()
        legStops = emptyList()
        curIdx = 0
        legNo = 1
        legTotal = 1
        fareRs = 0
    }
}
