package com.delhibus.app

import kotlin.math.max
import kotlin.math.min

enum class Phase { IDLE, RIDING, CHANGE, DONE }

/**
 * Pure trip logic (no Android). Follows the phone's GPS readings along the stops of the current bus.
 * A stop counts as passed only after 2 separate readings near it (GPS is not exact).
 */
class TripEngine(val legs: List<Leg>, val alarmStops: Int, val peak: Double) {
    var legIdx = 0
        private set
    var cur = 0
        private set
    var phase = Phase.RIDING
        private set
    var alarmDue = false
        private set
    private var alarmFired = false
    private var hits = IntArray(legs[0].stops.size)

    val leg: Leg get() = legs[legIdx]
    val last: Int get() = leg.stops.size - 1
    val stopsLeft: Int get() = last - cur
    val nextStop: Stop? get() = if (cur < last) leg.stops[cur + 1] else null
    val getOffStop: Stop get() = leg.stops[last]
    val hasMoreLegs: Boolean get() = legIdx < legs.size - 1
    val nextLeg: Leg? get() = if (hasMoreLegs) legs[legIdx + 1] else null

    fun minutesLeft(): Int {
        val m = (leg.cum[last] - leg.cum[cur]) * peak
        return max(0, Math.round(m).toInt())
    }

    /** Minutes until the bus should reach the stop where the alarm rings (estimate). */
    fun minutesToAlarmPoint(): Int {
        val target = max(cur, last - alarmThreshold())
        val m = (leg.cum[target] - leg.cum[cur]) * peak
        return max(1, Math.round(m).toInt())
    }

    fun alarmThreshold(): Int = if (last <= alarmStops) max(0, last - 1) else alarmStops

    /** Returns true if something visible changed (a stop passed, trip phase changed). */
    fun onLocation(lat: Double, lon: Double, accuracyM: Float): Boolean {
        if (phase != Phase.RIDING) return false
        val radius = min(150.0, max(70.0, accuracyM.toDouble() + 20.0))
        var found = -1
        val hi = min(last, cur + 3)
        for (j in cur + 1..hi) {
            val s = leg.stops[j]
            if (distanceM(lat, lon, s.lat, s.lon) <= radius) {
                found = j
                break
            }
        }
        var changed = false
        if (found >= 0) {
            for (j in cur + 1..hi) if (j != found) hits[j] = 0
            hits[found] = hits[found] + 1
            if (hits[found] >= 2) {
                cur = found
                for (j in hits.indices) hits[j] = 0
                changed = true
            }
        }
        if (changed) checkAlarmAndEnd()
        return changed
    }

    private fun checkAlarmAndEnd() {
        if (stopsLeft <= 0) {
            alarmDue = !alarmFired
            alarmFired = true
            phase = if (hasMoreLegs) Phase.CHANGE else Phase.DONE
        } else if (!alarmFired && stopsLeft <= alarmThreshold()) {
            alarmDue = true
            alarmFired = true
        }
    }

    /** Called by the time-based backup alarm. */
    fun forceAlarm() {
        if (phase == Phase.RIDING && !alarmFired) {
            alarmDue = true
            alarmFired = true
        }
    }

    fun consumeAlarm(): Boolean {
        val d = alarmDue
        alarmDue = false
        return d
    }

    /** User boarded the next bus after a change. */
    fun boardNext() {
        if (!hasMoreLegs) return
        legIdx += 1
        cur = 0
        hits = IntArray(leg.stops.size)
        alarmFired = false
        alarmDue = false
        phase = Phase.RIDING
        checkAlarmAndEnd()
    }
}
