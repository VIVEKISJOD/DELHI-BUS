package com.delhibus.app

import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Foreground service that follows the trip with the phone's GPS (works with the screen off),
 * keeps the notification up to date and rings the alarm before the stop.
 */
class TripService : Service() {

    companion object {
        const val ACTION_START = "com.delhibus.app.TRIP_START"
        const val ACTION_STOP = "com.delhibus.app.TRIP_STOP"
        const val ACTION_STOP_ALARM = "com.delhibus.app.TRIP_STOP_ALARM"
        const val ACTION_NEXT = "com.delhibus.app.TRIP_NEXT"
        const val ACTION_BACKUP = "com.delhibus.app.TRIP_BACKUP"
        const val CH_TRIP = "trip_progress"
        const val CH_ALARM = "trip_alarm"
        const val ID_TRIP = 11
        const val ID_ALARM = 12

        fun send(ctx: Context, action: String) {
            val i = Intent(ctx, TripService::class.java).setAction(action)
            try {
                androidx.core.content.ContextCompat.startForegroundService(ctx, i)
            } catch (e: Exception) {
                // the system did not allow it right now
            }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var lm: LocationManager? = null
    private var listener: LocationListener? = null
    private var wake: PowerManager.WakeLock? = null
    private var player: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private val stopRingTask = Runnable { stopRing() }
    private val endTask = Runnable { endService(false) }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun loc(): Context {
        val lang = Prefs.str(this, "lang", "")
        if (lang.isEmpty()) return this
        val cfg = Configuration(resources.configuration)
        cfg.setLocale(Locale(lang))
        return createConfigurationContext(cfg)
    }

    private fun hindi(): Boolean = Prefs.str(this, "lang", "") == "hi"

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val c = loc()
        val trip = NotificationChannel(CH_TRIP, c.getString(R.string.ch_trip), NotificationManager.IMPORTANCE_LOW)
        trip.setShowBadge(false)
        nm.createNotificationChannel(trip)
        val alarm = NotificationChannel(CH_ALARM, c.getString(R.string.ch_alarm), NotificationManager.IMPORTANCE_HIGH)
        alarm.setSound(null, null)
        alarm.enableVibration(false)
        nm.createNotificationChannel(alarm)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // A service started with startForegroundService must call startForeground quickly.
        try {
            val n = tripNotification()
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID_TRIP, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION)
            } else {
                startForeground(ID_TRIP, n)
            }
        } catch (e: Exception) {
            Trip.finish()
            stopSelf()
            return START_NOT_STICKY
        }

        when (intent?.action) {
            ACTION_STOP -> {
                endService(true)
                return START_NOT_STICKY
            }
            ACTION_STOP_ALARM -> {
                stopRing()
            }
            ACTION_NEXT -> {
                Trip.boardNext()
                scheduleBackup()
                refresh()
            }
            ACTION_BACKUP -> {
                val e = Trip.engine
                if (e != null && Trip.active) {
                    e.forceAlarm()
                    afterUpdate()
                }
            }
            else -> {
                if (!Trip.active || Trip.engine == null) {
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                    return START_NOT_STICKY
                }
                startTracking()
                scheduleBackup()
            }
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------ GPS

    private fun startTracking() {
        if (listener != null) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        try {
            val w = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "delhibus:trip")
            w.acquire(6L * 60L * 60L * 1000L)
            wake = w
        } catch (e: Exception) {
            // not critical
        }
        val manager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        lm = manager
        val l = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                val changed = Trip.onLocation(location.latitude, location.longitude, if (location.hasAccuracy()) location.accuracy else 30f)
                if (changed) scheduleBackup()
                afterUpdate()
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Old Android versions still call this")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        }
        listener = l
        val save = Prefs.bool(this, "gps_save", false)
        val interval = if (save) 6000L else 2000L
        try {
            val providers = if (save) listOf(LocationManager.NETWORK_PROVIDER)
            else listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            for (p in providers) {
                if (manager.isProviderEnabled(p)) {
                    manager.requestLocationUpdates(p, interval, 0f, l, Looper.getMainLooper())
                }
            }
        } catch (e: SecurityException) {
            endService(true)
        }
    }

    private fun afterUpdate() {
        val e = Trip.engine ?: return
        refresh()
        if (e.consumeAlarm()) {
            val c = loc()
            val h = hindi()
            when (e.phase) {
                Phase.CHANGE -> ring(
                    c.getString(R.string.trip_change_title),
                    c.getString(R.string.trip_change_text, e.getOffStop.display(h), e.nextLeg?.route?.number ?: "")
                )
                Phase.DONE -> ring(
                    c.getString(R.string.trip_arrived_title),
                    c.getString(R.string.trip_arrived_text, e.getOffStop.display(h))
                )
                else -> ring(
                    c.getString(R.string.trip_alarm_title),
                    c.getString(R.string.trip_alarm_text, e.stopsLeft, e.getOffStop.display(h))
                )
            }
        }
        if (e.phase == Phase.DONE) {
            // trip finished by itself: stop tracking, keep the arrival message and the ringing for a short while
            stopTracking()
            handler.removeCallbacks(endTask)
            handler.postDelayed(endTask, 20000L)
        }
    }

    private fun stopTracking() {
        val l = listener
        if (l != null) {
            try {
                lm?.removeUpdates(l)
            } catch (e: Exception) {
                // ignore
            }
        }
        listener = null
        cancelBackup()
    }

    // ------------------------------------------------------------ notification

    private fun openApp(): PendingIntent {
        val i = Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun actionIntent(code: Int, action: String): PendingIntent {
        val i = Intent(this, TripService::class.java).setAction(action)
        return PendingIntent.getForegroundService(this, code, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private fun tripNotification(): Notification {
        val c = loc()
        val h = hindi()
        val e = Trip.engine
        val title: String
        val text: String
        if (!Trip.active || e == null) {
            title = c.getString(R.string.app_name)
            text = c.getString(R.string.trip_starting)
        } else if (e.phase == Phase.CHANGE) {
            title = c.getString(R.string.trip_change_title)
            text = c.getString(R.string.trip_change_text, e.getOffStop.display(h), e.nextLeg?.route?.number ?: "")
        } else if (e.phase == Phase.DONE) {
            title = c.getString(R.string.trip_arrived_title)
            text = c.getString(R.string.trip_arrived_text, e.getOffStop.display(h))
        } else {
            title = c.getString(R.string.trip_title, e.leg.route.number, e.getOffStop.display(h))
            text = c.getString(
                R.string.trip_text,
                e.nextStop?.display(h) ?: e.getOffStop.display(h),
                e.stopsLeft,
                e.minutesLeft()
            )
        }
        val b = NotificationCompat.Builder(this, CH_TRIP)
            .setSmallIcon(R.drawable.ic_fg)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
            .setContentIntent(openApp())
            .addAction(0, c.getString(R.string.trip_off_btn), actionIntent(1, ACTION_STOP))
        return b.build()
    }

    private fun refresh() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        try {
            nm.notify(ID_TRIP, tripNotification())
        } catch (e: Exception) {
            // notifications may be off
        }
    }

    // ------------------------------------------------------------ alarm

    private fun ring(title: String, text: String) {
        val c = loc()
        Trip.ringing = true
        val n = NotificationCompat.Builder(this, CH_ALARM)
            .setSmallIcon(R.drawable.ic_fg)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .addAction(0, c.getString(R.string.trip_stop_alarm), actionIntent(2, ACTION_STOP_ALARM))
            .build()
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(ID_ALARM, n)
        } catch (e: Exception) {
            // notifications may be off; sound and vibration still work
        }
        if (Prefs.bool(this, "alarm_sound", true)) startSound()
        if (Prefs.bool(this, "alarm_vibrate", true)) startVibration()
        handler.removeCallbacks(stopRingTask)
        handler.postDelayed(stopRingTask, 60000L)
    }

    private fun startSound() {
        try {
            if (player != null) return
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                ?: return
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(this, uri)
            mp.isLooping = true
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) {
            player = null
        }
    }

    private fun startVibration() {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            vibrator = v
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 700, 400), 0))
        } catch (e: Exception) {
            // no vibrator
        }
    }

    private fun stopRing() {
        handler.removeCallbacks(stopRingTask)
        try {
            player?.stop()
        } catch (e: Exception) {
            // ignore
        }
        try {
            player?.release()
        } catch (e: Exception) {
            // ignore
        }
        player = null
        try {
            vibrator?.cancel()
        } catch (e: Exception) {
            // ignore
        }
        Trip.ringing = false
    }

    // ------------------------------------------------------------ backup alarm (time based)

    private fun backupIntent(): PendingIntent = actionIntent(3, ACTION_BACKUP)

    private fun scheduleBackup() {
        val e = Trip.engine ?: return
        if (e.phase != Phase.RIDING) return
        val ms = (e.minutesToAlarmPoint() * 1.3 * 60000.0).toLong() + 30000L
        val at = System.currentTimeMillis() + ms
        val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, backupIntent())
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, backupIntent())
            }
        } catch (ex: Exception) {
            // the backup alarm is optional
        }
    }

    private fun cancelBackup() {
        try {
            val am = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            am.cancel(backupIntent())
        } catch (e: Exception) {
            // ignore
        }
    }

    // ------------------------------------------------------------ end

    private fun endService(resetTrip: Boolean) {
        handler.removeCallbacks(endTask)
        stopRing()
        stopTracking()
        if (resetTrip) Trip.finish()
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (resetTrip) nm.cancel(ID_ALARM)
        } catch (e: Exception) {
            // ignore
        }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopRing()
        stopTracking()
        try {
            wake?.let { if (it.isHeld) it.release() }
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
